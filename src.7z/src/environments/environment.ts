export const environment = {
  production: true,


//    urlLogincheck : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/signin",
//  urlRegister : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  urlFetchListApps :  "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  //  /* url for delete application from app-mgmt */
//    urlDelete : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  //  /*url for recreating secret */
//   urlCreateSecret : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  //  /*url for editing application from app-mgmt */
//    urlGetEdit : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  //  /*url for post editing application in edit-item */
//    urlPatch : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/",
//  //  /*url for getting countries i profile-mgmt */
//    UrlGetCountry:'https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/country',
//  // /*url for getting edit profile page*/ 
//   urlGetEditProfile:"https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/developers3/",
//  // /*url for post  edit profile*/ 
//   urlEditPostProfile:"https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/developers/",
//  // /*Get Question in signup */
//   urlGetQuestions :"https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net//api/v1/developer/Questionire",
//  // /*url for email sending */
//   urlEmailSend : "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/communication/",
//  // /*url for otp verify */
//   urlVerifyCode:"https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/communication/code",
//  // /*url for Profile Register */
//   urlProfileRegister :"https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/developers",

//   urlForgotnResetPwd:"https://b2cbcbsricmsdevportaldev.b2clogin.com/b2cbcbsricmsdevportaldev.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1_Standard_forgotPassword_dev_Portal&client_id=2ff53c98-c76b-4a77-a6e2-8583bb0084be&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fazapp-eus2-dev-cms-testdeveloperportal.azase-eus2-dev-001.appserviceenvironment.net%2Flanding&scope=openid&response_type=id_token&prompt=login",


// urlLogincheck : "#{urlLogincheck}#",
// urlRegister : "#{urlRegister}#",
// urlFetchListApps :  "#{urlFetchListApps}#",
// urlDelete:"#{urlDelete}#",
// urlCreateSecret:"#{urlCreateSecret}#",
// urlGetEdit:"#{urlGetEdit}#",
// urlPatch:"#{urlPatch}#",
// UrlGetCountry: "#{UrlGetCountry}#",
// urlGetEditProfile:"#{urlGetEditProfile}#",
// urlEditPostProfile:"#{urlEditPostProfile}#",
// urlGetQuestions:"#{urlGetQuestions}#",
// urlEmailSend:"#{urlEmailSend}#",
// urlVerifyCode:"#{urlVerifyCode}#",
// urlProfileRegister:"#{urlProfileRegister}#",
// urlForgotnResetPwd:"#{urlForgotnResetPwd}#"



};



