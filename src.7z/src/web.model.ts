export  interface Web
{
     RedirectUris: string ;
}
