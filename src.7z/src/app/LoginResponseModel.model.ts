export interface LoginResponseModel
    {

        errorMessage:string;
        statusCode:string;
        data:string;
    }