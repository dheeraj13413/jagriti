import { Server } from 'http';
import { Web } from './web.model';

export interface AppResponseModel 
    {
        clientId:  string;  
        oid:   string  ;
        clientSecret: string  ;
        displayName:    string ;
        web:Web ;
        id:string;
        imageBase64:string;
        application_Type? :string;
 application_Purpose?:string;
 

      
     
        
    }
