export interface SignupResponseModel
    {

        errorMessage:string;
        statusCode:string;
        data:string;
    }