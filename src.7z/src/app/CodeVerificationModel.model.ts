export interface CodeVerificationModel
    {
        EmailAddress:string;
        Code:string;


    }