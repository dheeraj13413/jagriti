import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AppResponseModel } from 'src/app/AppResponseModel.model';
import { AppManagementComponent } from '../app-management/app-management.component';
import { ResponseModel } from '../ResponseModel.model';
import { EditResponseModel } from '../EditResponseModel.model';
import { EditPostRequestModel } from '../EditPostRequestModel.model';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { environment } from 'src/environments/environment.prod';

@Component({
  selector: 'app-edit-app',
  templateUrl: './edit-app.component.html',
  styleUrls: ['./edit-app.component.css'],
})
export class EditAppComponent implements OnInit {

  url = "";
  
  //url = '../../assets/images/selectlogo.PNG'
  appId:number  ;
  editItemArray: AppResponseModel[];
  editItemdata: AppResponseModel;
  editPostResponseData:Object;
  displayName:string;
  clientId:string;
  checkedPolicy:boolean;
  checkedTerms:boolean;
  checkedCodeConduct:boolean;
  uoid:string ="21a13f14-9df0-43aa-b1ab-ea6cc3afbcf8";
  urlPatch:string = "";
  urisArray: string[] ;
  base64imgForHtmlBind: string = "";
  base64Prefix= "data:image/png;base64,";
  base64ImageUrl:SafeUrl;
  imgBase64blnk = false;
  base64imgWithoutprefix: string;
  convertImage: string;
  imagebase64edit = false;
  isEditForm = true;
  isEditComplete = false;
  data:string = sessionStorage.getItem('id');
  urlGetEdit: string;
  editWait= false;
  redirectUris: string;


 
  
  


  

 // @Input() appId: string;

 constructor(private route : ActivatedRoute,private http:HttpClient,private domSanitizer: DomSanitizer,
  private router: Router){

  
 }
  

  ngOnInit(): void {
    if(this.data!= null){
      console.log("session id "+this.data);
     

    
  
  
  console.log("in ngoninit");
    //console.log(this.appId);

     // subscribe to the parameters observable
  this.route.paramMap.subscribe(params => {
  
    this.appId =+ params.get('id');
    console.log(params.get('id'));
    this.editItemApiCall();
    
  })
  this.urlPatch = environment.urlPatch+this.data+"/applications/"+this.appId;
  }
  else{
    this.router.navigate(['landing']);

  }
  }

  onFileSelect(e: any) {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
        this.convertImage = this.url;
        console.log("url" +this.convertImage);
        if(this.url!=this.base64imgForHtmlBind){
          console.log("in 2nd if ")
          console.log("convertImage "+this.url);
          this.imagebase64edit = true;
          console.log("imagebase64edit "+this.imagebase64edit);
  
        }
      };
    }
  }


  editItemApiCall(){
  this.urlGetEdit = environment.urlGetEdit+this.data+"/applications/"+this.appId;
  
    return this.http.get<EditResponseModel>(

        this.urlGetEdit)
    .subscribe(editItems =>{
      console.log(editItems);
      this.editItemdata = editItems.data

      
    
    this.base64imgWithoutprefix = this.editItemdata.imageBase64;
    if(this.base64imgWithoutprefix == null){
console.log("in base64imgWithoutprefix is null")
      this.imgBase64blnk = true;
      console.log("imgbase64blnk "+this.imgBase64blnk);
    }
    this.imgBase64blnk = false;
  

      this.base64imgForHtmlBind=this.base64Prefix+this.editItemdata.imageBase64;
    
      this.imagebase64edit= false;
      //this.base64imgForHtmlBind=this.editItemdata.imageBase64;
      console.log("base64 "+ this.base64imgForHtmlBind);
      this.base64ImageUrl = this.domSanitizer.bypassSecurityTrustResourceUrl(this.base64imgForHtmlBind);
     console.log("base64Url "+this.base64ImageUrl);
      this.editItemdata.web.uri=this.editItemdata.web.redirectUris.join();
      this.redirectUris = this.editItemdata.web.uri;
      this.urisArray =  this.editItemdata.web.uri.split(',');
      console.log("urisArray "+this.urisArray);
    });
  
  }


 


  checkboxPolicyClicked(value:boolean){
    this.checkedPolicy = value;
    console.log("checkedPolicy value" ,this.checkedPolicy);
  }

  checkboxTermsClicked(value:boolean){
    this.checkedTerms = value;
    console.log("checkedTerms value" ,this.checkedTerms);
  }

  checkboxCodeConductClicked(value:boolean){
    this.checkedCodeConduct = value;
    console.log("checkedCodeConduct value" ,this.checkedCodeConduct);
  }
  
 
  callPostEditService(
    )
    {
      this.editWait= true;
      // this.editItemdata.web.uri=this.editItemdata.web.redirectUris.join();
      // this.urisArray =  this.editItemdata.web.uri.split(',');
      // console.log("urisArray "+this.urisArray)
      //this.editItemdata.web.redirectUris = [];
            this.editItemdata.web.uri =this.editItemdata.web.redirectUris.join();
       this.urisArray = this.editItemdata.web.uri.split(',');
      
      // if(this.url.substring(22)!=null&&this.url.substring(22)!= this.editItemdata.imageBase64 && this.editItemdata.imageBase64!=null)
      // {
      //   console.log("image64check");
      //   console.log(this.url.substring(22));
      //   if(this.url.substring(22)==null)
      //   {
      //     console.log("check url null or not");
      //     console.log(this.url.substring(22));
      //   }

      //   console.log(this.url.substring(22)!=null&&this.url.substring(22)!= this.editItemdata.imageBase64 && this.editItemdata.imageBase64!=null?this.url.substring(22):this.editItemdata.imageBase64);
      // }
    const editAppData:EditPostRequestModel = {
      
      
      ApplicationName: this.editItemdata.displayName , 
     
      RedirectUrls:  this.editItemdata.web.redirectUris,
      // CodeOfConductAttestation: this.checkedCodeConduct ,
      // TOSAttestation:    this.checkedTerms ,
      // PrivacyPolicy:this.checkedPolicy,
      Logo:null,
      UOID:this.data,
      imageBase64: this.editItemdata.imageBase64,
      application_Purpose:this.editItemdata.application_Purpose,
      application_Type:this.editItemdata.application_Type
     // imageBase64: this.url != this.base64imgForHtmlBind && this.base64imgWithoutprefix != null ? this.url : this.base64imgForHtmlBind,
      
      
    

    };
    return this.http.patch<EditResponseModel>(this.urlPatch,editAppData).
    subscribe(editResponseData=>{
     // this.editPostResponseData = editResponseData;
     console.log(editResponseData);
      console.log(editResponseData.errorMessage);
      if(editResponseData.errorMessage == null){
       // alert("Details are successfully edited.Thanks!!!")
      this.isEditForm= false;
      this.isEditComplete= true;
      this.editWait = false;
      }

     // this.isEditComplete= false;
     
      // else{
      //   alert("There is an error while editing.Thanks!!!")
      // }
    

  }
  // ,error=>{
  //   console.log(error.message);
  // }
  )
}
}








  // this.appManagementComponent.editItemApiCall().subscribe(
    //   (editItems) =>{
    //     console.log(editItems);
    // editItems.data.forEach(x=>{
    //   this.editItemArray.push(x);
    //  })
    //  }
    //)