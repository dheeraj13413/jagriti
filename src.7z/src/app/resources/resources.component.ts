import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {
  resource= false;
  postResource= false;

  constructor(private router: Router) { }
  data:string = sessionStorage.getItem('id');

  ngOnInit(): void {
    console.log("sessionitem "+sessionStorage.getItem('id'));
    console.log("data before if "+this.data);


    if(this.data!= "abc"){
      this.postResource = true;

      console.log("session id "+this.data);
      this.router.navigate(['resources']);

    
  }
  else{
    this.postResource = false;
    this.resource = true;
    this.router.navigate(['resources']);

  }
  }

}
