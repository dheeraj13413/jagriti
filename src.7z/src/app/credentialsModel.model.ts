export interface credentialsModel
    {

        UserName:string;
        Password:string;
    }