import { AppResponseModel } from "./AppResponseModel.model";

export interface EditResponseModel
    {
       
        // constructor(public errorMessage: string, public statusCode: string, public data:AppResponseModel[])
        //  {

        //  }
        errorMessage : string ;
        statusCode :  string ;
        data  :AppResponseModel;
        
      
    }