export interface EditPostRequestModel 
{
    ApplicationName:  string;  
    RedirectUrls: string[] ;
    // CodeOfConductAttestation: boolean  ;
    // TOSAttestation:    boolean ;
    // PrivacyPolicy:boolean ;
    Logo:[];
    UOID:string;
    imageBase64:string;
    application_Type :string;
    application_Purpose:string;
    
}
