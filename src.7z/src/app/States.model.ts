export interface States

    {
        state_Name:string;
        id:string;


    }