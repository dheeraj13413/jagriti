import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataStorageService } from '../shared/data-storage.service';

@Component({
  selector: 'app-welcome-header',
  templateUrl: './welcome-header.component.html',
  styleUrls: ['./welcome-header.component.css']
})
export class WelcomeHeaderComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
   
    var data = sessionStorage.getItem('id');
    if(data!= "null"){
      console.log("session id "+data);
      this.router.navigate(['welcome']);
  }
  else{
    this.router.navigate(['landing']);

  }
    
  }


  

 
}
