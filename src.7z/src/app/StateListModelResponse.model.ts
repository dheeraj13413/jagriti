import { States } from "./States.model";

export interface StateListModelResponse
    {
        errorMessage:string;
        statusCode:string;
        data:States[];
    }