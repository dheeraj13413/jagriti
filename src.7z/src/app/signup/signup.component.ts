import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { timeStamp } from 'console';
import { DeveloperOrgRegModel } from '../DeveloperOrgRegModel.model';
import { DeveloperRegistartionModel } from '../DeveloperRegistartionModel.model';
import { CountryListModelResponse } from '../CountryListModelResponse.model';
import{StateListModelResponse} from '../StateListModelResponse.model';
import { DataStorageService } from '../shared/data-storage.service';
import { Countries } from '../Countries.model';
import { States } from '../States.model';
import { OrganizationRegistartionModel } from '../OrganizationRegistartionModel.model';
import{QuestionsListModel} from '../QuestionsListModel.model';
import { Questions } from '../Questions.model';
import { ReadVarExpr } from '@angular/compiler';
import { EmailAddressSentModel } from '../EmailAddressSentModel.model';
import { environment } from 'src/environments/environment.prod';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  step1=true;
  step2= false;
  step3= false;
  step4= false;
  otptext = false;
  reset = false;
  countryList: Object;

  verify = false;
  EMail="";
  Password= "";
  ConfirmPassword="";
  DisplayName="";
  Lastame= "";
  FirstName= "";
  StreetAddress= "";
  City= "";
  Country= "";
  State= "";
  ZipCode= "";
  PhoneNumber= "";
  OrganizationName="";
  OrganizationTaxID= "";
  OrgStreetAddress :string = "";
        OrgCity :string = "";
        OrgState :string= "";
        OrgCountry :string= "";
        OrgZipCode :string= "";
        OrgAltEmail :string= "";
        OrgPhoneNumber:string = "";
  countryName: string;
  loadedCountry: Countries[]=[];
  id: number;
  getCountryData: CountryListModelResponse;
  selectedgetCountryData= "";
  selectedCountryId: string;
  selectedId: HTMLElement;
  value: any;
  getStateData: StateListModelResponse;
  loadedState: States[]=[];
  stateName: string;
  urlState: string;
  getQuestionsData: QuestionsListModel;
  loadedQuestions: Questions[]=[];
  HTMLCode= "";
  hol: HTMLElement;
  ques: string;
  sth: (ques: any) => HTMLElement;
  htmlText: any;
  QuesCheckIDs: number[]=[];
  idcheck: number;
  QuesIDs: number[];
  CheckedTerms: boolean;
  CheckedCodeConduct: boolean;
  otp:string;
  emailValid= false;
  registerProfilError=false;
  registerProfile= true;
  registerProfileSuccess= false;
  text = "";
  cpwd = false;
  Carin_Bio_Url = "";
  Policy_Url = "";
  InformationSecurityPolicy= false;
  otpVerify= false;
  otpVerifyFail = false;
;


  




  constructor(private dataStorageService: DataStorageService,private http:HttpClient) { }

  ngOnInit(): void {
    this.selectCountryApi();
    
  }
  add(){ 

    this.otptext = true;
    this.reset = true;
    this.verify = true;
  // let row = document.createElement('div');   
  // row.className = 'row'; 
  // row.innerHTML = ` 
  // <br> 
  // <input type="text">`; 
  // document.querySelector('.showInputField').appendChild(row); 
 
  // let row1 = document.createElement('div');   
  // row1.className = 'row'; 
  // row1.innerHTML = ` 
  // <br> 
  // <button type="button">`; 
  // document.querySelector('.showResetButton').appendChild(row1); 
}

nextForm(){
  this.step1=false;
  this.step2= true;
  this.step3= false;
  this.step4= false;

}

nextOnOrgForm(){
  this.step1=false;
  this.step2= false;
  this.step3= true;
  this.step4= false;
  this.getQuestions();


}


nextOnQuesForm(){

  this.step1=false;
  this.step2= false;
  this.step3= false;
  this.step4= true;


}

prevFromOrg(){

  this.step1=true;
  this.step2= false;
  this.step3= false;
  this.step4= false;


}

checkboxTermsClicked(value:boolean){
  this.CheckedTerms = value;
  console.log("checkedTerms value" ,this.CheckedTerms);
}

checkboxCodeConductClicked(value:boolean){
  this.CheckedCodeConduct = value;
  console.log("checkedCodeConduct value" ,this.CheckedCodeConduct);
}
clearLoadedQuestions(){
  this.loadedQuestions = [];
}


saveValues(step1FormData:DeveloperRegistartionModel){
  this.DisplayName=step1FormData.DisplayName;
  this.EMail=step1FormData.EMail;
  this.FirstName= step1FormData.FirstName;
  this.Lastame= step1FormData.Lastame;
  this.Password=step1FormData.Password;
  this.City=step1FormData.City;
  this.Country=step1FormData.Country;
  this.PhoneNumber= step1FormData.PhoneNumber;
  this.ZipCode= step1FormData.ZipCode;
  this.StreetAddress= step1FormData.StreetAddress;
  this.otp = step1FormData.otp;
  
  

  console.log("DisplayName "+this.DisplayName);

}

saveOrgValues(step2FormData:OrganizationRegistartionModel){

this.OrgAltEmail =step2FormData.OrgAltEmail;
this.OrgCity= step2FormData.OrgCity;
this.OrgCountry = step2FormData.OrgCountry;
this.OrgState= step2FormData.OrgState;
this.OrgZipCode= step2FormData.OrgZipCode;
this.OrganizationName= step2FormData.OrganizationName;
this.OrganizationTaxID= step2FormData.OrganizationTaxID;
this.Carin_Bio_Url =step2FormData.Carin_Bio_Url;
this.Policy_Url = step2FormData.Policy_Url;
this.InformationSecurityPolicy = step2FormData.InformationSecurityPolicy;
this.OrgPhoneNumber = step2FormData.OrgPhoneNumber;

}

saveQuestionValues(){

  this.QuesIDs = this.QuesCheckIDs;
  console.log("QuesIDs "+ this.QuesIDs);
}

OnRegister(profileDate:DeveloperOrgRegModel){ 
  profileDate.DisplayName = this.DisplayName;
  profileDate.FirstName = this.FirstName;
  profileDate.Lastame = this.Lastame;
  profileDate.Password = this.Password;
  profileDate.PhoneNumber = this.PhoneNumber;
  profileDate.EMail = this.EMail;
  profileDate.StreetAddress= this.StreetAddress;
  profileDate.City= this.City;
  profileDate.State = this.State;
  profileDate.ZipCode= this.ZipCode;
  profileDate.Country= this.Country;
   profileDate.QuesIDs =this.QuesIDs;
   profileDate.CheckedTerms = this.CheckedTerms;
   profileDate.CheckedCodeConduct = false;
   profileDate.OrganizationName = this.OrganizationName;
   profileDate.OrganizationTaxID = this.OrganizationTaxID;
   profileDate.OrgCountry = this.OrgCountry;
   profileDate.OrgState = this.OrgState;
   profileDate.OrgStreetAddress = this.OrgStreetAddress;
   profileDate.OrgZipCode = this.OrgZipCode;
   profileDate.OrgCity = this.OrgCity;
   profileDate.OrgAltEmail = this.OrgAltEmail;
   profileDate.Policy_Url =this.Policy_Url;
   profileDate.Carin_Bio_Url = this.Carin_Bio_Url;
   profileDate.InformationSecurityPolicy = this.InformationSecurityPolicy;
   profileDate.OrgPhoneNumber = this.OrgPhoneNumber;



  this.dataStorageService.onProfileRegister(profileDate.Password,profileDate.DisplayName,
    profileDate.FirstName,profileDate.Lastame,profileDate.EMail,profileDate.StreetAddress,
    profileDate.City,profileDate.State,profileDate.Country,profileDate.ZipCode,
    profileDate.PhoneNumber,profileDate.OrganizationName,profileDate.OrganizationTaxID,
    profileDate.OrgStreetAddress,profileDate.OrgCity,profileDate.OrgState,
    profileDate.OrgCountry,profileDate.OrgZipCode,profileDate.OrgAltEmail,profileDate.QuesIDs,
    profileDate.CheckedTerms,profileDate.CheckedCodeConduct,profileDate.Policy_Url,
    profileDate.Carin_Bio_Url,profileDate.InformationSecurityPolicy,profileDate.OrgPhoneNumber
    ).subscribe(responseData =>{

      console.log("responseData "+responseData);
      if(responseData.body.errorMessage!=null)
      {
        this.registerProfilError = true;
        this.registerProfile= false;
      }
      else{
        this.registerProfile = false;
        this.registerProfileSuccess = true;
      }
    })


}
selectCountryApi(){
  return this.http.get<CountryListModelResponse>(
    environment.UrlGetCountry) 
      
  .subscribe((getCountry) =>{
    console.log(getCountry);
   // this.getCountryData=getCountry.data;
    this.getCountryData=getCountry;
    //console.log(getCountry[0].country_Name);
    //console.log(this.getCountryData[0].country_Name);
    // console.log(this.getCountryData[0].id);

     getCountry.data.forEach(x =>{
        this.countryName =  x.country_Name;
      //  this.id = x.id;
        this.loadedCountry.push(x);
        console.log("loadedCountry "+this.loadedCountry);
        

     })
    
    
})


}


selectState(event){
 this.value= event.target.value;
//  this.selectedId =document.getElementById(this.value);
//this.selectedCountryId= id;
console.log("id "+this.selectedId);
console.log("id "+this.value);
this.urlState= "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/state/country/"+this.value;
console.log("urlState "+this.urlState);
this.selectSatateApi();



}
isSelected(value:string){

  this.idcheck = Number(value);
if(this.idcheck>0){
  this.QuesCheckIDs.push(this.idcheck);

}
console.log(this.QuesCheckIDs);

 

  

}

selectSatateApi(){
  
 
  return this.http.get<StateListModelResponse>(this.urlState)
      
  .subscribe((getState) =>{
    console.log(getState);
   // this.getCountryData=getCountry.data;
    this.getStateData=getState;
    //console.log(getCountry[0].country_Name);
    //console.log(this.getCountryData[0].country_Name);
    // console.log(this.getCountryData[0].id);

    this.getStateData.data.forEach(x =>{
        this.stateName =  x.state_Name;
      //  this.id = x.id;
        this.loadedState.push(x);
        console.log("loadedState "+this.loadedState);
        

     })
    

})

}

getQuestions(){

  return this.http.get<QuestionsListModel>(
    environment.urlGetQuestions
  )
      
  .subscribe((getQuestions) =>{
    console.log(getQuestions);
   // this.getCountryData=getCountry.data;
    this.getQuestionsData=getQuestions;
    this.HTMLCode = "<!DOCTYPE html <html> <body>" + this.getQuestionsData +"</body></html>";
 

    //console.log(getCountry[0].country_Name);
    //console.log(this.getCountryData[0].country_Name);
    // console.log(this.getCountryData[0].id);

    this.getQuestionsData.data.forEach(x =>{
      //  this.stateName =  x.state_Name;
      //  this.id = x.id;

            //  x.questionText       = "<!DOCTYPE html <html> <body>" + x.questionText+"</body></html>"; 
            //  console.log("questionText "+ x.questionText);
            
         //var holder = document.createElement('<input type="checkbox" name="1" id="c1">');

        this.ques= x.questionText;
        var el = document.createElement( 'html' );
el.innerHTML = "<html><head><title>titleTest</title></head><body><a href='test0'>test01</a><a href='test1'>test02</a><a href='test2'>test03</a></body></html>";
this.hol= el;
const { htmlToText } = require('html-to-text');

//const html = '<h1>Hello World</h1>';
const html = x.questionText;
const text = htmlToText(html, {
  wordwrap: false
});

this.htmlText = text;
console.log(text); // Hello World
        //  var holder:HTMLElement
        //     holder.innerText = x.questionText;
        //     this.hol = holder.innerHTML;

          //   var stringToHTML = function (this.ques) {
          //     var parser = new DOMParser();
          //     var doc = parser.parseFromString(ques, 'text/html');
          //     console.log("stringToHTML");
          //     return doc.body;

              
          //   };

          //  this.sth= stringToHTML

        this.loadedQuestions.push(x);
        console.log("loadedQuestions "+this.loadedQuestions);
        

     })
    

})



}
onEmailCommunication(){
this.onEmailSend(this.EMail).subscribe(responseData =>{

  console.log("responseData "+responseData);
  if(responseData == false){
    this.emailValid = true;
  }
})
}



urlEmailSend = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/communication/";

onEmailSend(EmailAddress:string){

  console.log("emailurl "+this.urlEmailSend);
  const emailData:EmailAddressSentModel = {EmailAddress:EmailAddress};
  return  this.http.post(
    environment.urlEmailSend,emailData
       
        )

}

onOtpVerify(){
  console.log("otp "+this.otp);
  console.log("email "+this.EMail);
this.dataStorageService.onVerifyCode(this.EMail,this.otp).subscribe(responseData =>{

  console.log("responseData "+responseData);
  if(responseData)
  {
    this.otpVerifyFail = false;
    this.otpVerify = true;
  }
  else{
    this.otpVerify = false;
    this.otpVerifyFail = true;
  }
})

}



onKeyUp(x){

 this.text = x.target.value;

 console.log("text "+this.text);
 console.log("cpss "+this.ConfirmPassword);
 console.log("password "+this.Password);
 if(this.ConfirmPassword.length<8 || this.ConfirmPassword!=this.Password)
 {
   this.cpwd = true;
 }
 else{
   this.cpwd= false;
 }
 
}


}





