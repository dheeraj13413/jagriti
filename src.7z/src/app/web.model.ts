export  interface Web
{
     redirectUris: string[];
     uri:string ;
}
