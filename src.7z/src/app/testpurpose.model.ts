export interface Testpurpose
    {
        base64Stringimg:string;

    }