import { HttpClient } from '@angular/common/http';
import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Countries } from '../Countries.model';
import { CountryListModelResponse } from '../CountryListModelResponse.model';
import { DeveloperOrgRegModel } from '../DeveloperOrgRegModel.model';
import { EditProfileDataResponseModel } from '../EditProfileDataResponseModel.model';
import { EditProfileResponseModel } from '../EditProfileResponseModel.model';
import { LoginResponseModel } from '../LoginResponseModel.model';
import { StateListModelResponse } from '../StateListModelResponse.model';
import{ProfileMgmtResponseModel} from '../ProfileMgmtResponseModel'
import { States } from '../States.model';
import { environment } from 'src/environments/environment.prod';

@Component({
  selector: 'app-profile-mgmt',
  templateUrl: './profile-mgmt.component.html',
  styleUrls: ['./profile-mgmt.component.css']
})
export class ProfileMgmtComponent implements OnInit {
  OrganizationTaxID= "";
  OrganizationName= "";
  Oid: string;
  city:string;
  ProfileData: EditProfileDataResponseModel;
  Editcity: string;
  EditStreetAddress: string;
  countryName: string;
  loadedCountry: Countries[]=[];
  getCountryData: CountryListModelResponse;
  EditCountry: string;
  selectedId: HTMLElement;
  value: any;
  urlState: string;
  getStateData: StateListModelResponse;
  loadedState: States[]=[];
  stateName: string;
  EditState: string;
  EditZipCode: string;
  EditPhone: string;
  EditOrgName: string;
  EditOrgTaxID: string;
  EditOrgStreet: string;
  EditOrgCity: string;
  EditOrgState: string;
  EditOrgCountry: string;
  EditOrgZipCode: string;
  urlPatch: string;
  urlDelete: string;
  editSuccesfullMsg= false;
  editwaiting= false;
  isLoading= true;
  isEditProfileGet=false;
  FirstName:string;
  LastName:string;
  OrgPhoneNumber:string;
  OrgAltEmail:string;
  Carin_Bio_Url:boolean;
  deleteFail= false;
  deleteSuccess= false;
 

  constructor(private http:HttpClient,private router: Router) { }
  data:string = sessionStorage.getItem('id');

  ngOnInit(): void {
    if(this.data!= null){
      console.log("session id "+this.data);
     

    
  
  
    this.selectCountryApi();

    this.editProfileItemApiCall();
}
else{
  this.router.navigate(['landing']);

}
  }
  selectCountryApi(){
    return this.http.get<CountryListModelResponse>(
      environment.UrlGetCountry) 
        
    .subscribe((getCountry) =>{
      console.log(getCountry);
     
     // this.getCountryData=getCountry.data;
      this.getCountryData=getCountry;
      //console.log(getCountry[0].country_Name);
      //console.log(this.getCountryData[0].country_Name);
      // console.log(this.getCountryData[0].id);
  
       getCountry.data.forEach(x =>{
          this.countryName =  x.country_Name;
        //  this.id = x.id;
          this.loadedCountry.push(x);
          console.log("loadedCountry "+this.loadedCountry);
          
  
       })
      
      
  })
  
  
  }
  selectState(event){
    this.value= event.target.value;
   //  this.selectedId =document.getElementById(this.value);
   //this.selectedCountryId= id;
   console.log("id "+this.selectedId);
   console.log("id "+this.value);
   this.urlState= "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/state/country/"+this.value;
   console.log("urlState "+this.urlState);
   this.selectSatateApi();
   
   
   
   }

   selectSatateApi(){
  
 
    return this.http.get<StateListModelResponse>(this.urlState)
        
    .subscribe((getState) =>{
      console.log(getState);
     // this.getCountryData=getCountry.data;
      this.getStateData=getState;
      //console.log(getCountry[0].country_Name);
      //console.log(this.getCountryData[0].country_Name);
      // console.log(this.getCountryData[0].id);
  
      this.getStateData.data.forEach(x =>{
          this.stateName =  x.state_Name;
        //  this.id = x.id;
          this.loadedState.push(x);
          console.log("loadedState "+this.loadedState);
          
  
       })
      
  
  })
  
  }
  

  editProfileItemApiCall(){
    this.Oid = "253c819a-7edf-46c9-b669-dbabc409f9fe";
    return this.http.get<EditProfileResponseModel>(
     environment.urlGetEditProfile+this.data ) 
         
    .subscribe(editItems =>{
      console.log(editItems);
     // console.log("data "+editItems.data.city);
        this.ProfileData = editItems.data;
     this.Editcity =editItems.data.city;
     this.EditStreetAddress = editItems.data.streetAddress;
     this.EditCountry = editItems.data.country;
     this.EditState = editItems.data.state;
     this.EditZipCode = editItems.data.zipCode;
     this. EditPhone = editItems.data.phoneNumber;
     this.EditOrgName =editItems.data.organizationName;
     this.EditOrgTaxID = editItems.data.organizationTaxID;
     this.EditOrgStreet = editItems.data.orgStreetAddress;
     this.EditOrgCity = editItems.data.orgCity;
     this.EditOrgState = editItems.data.orgState;
     this.EditOrgCountry = editItems.data.orgCountry;
     this.EditOrgZipCode = editItems.data.orgZipCode;
     this.OrgPhoneNumber = editItems.data.orgPhoneNumber;
     this.FirstName = editItems.data.firstName;
     this.LastName = editItems.data.lastame;
     this.OrgAltEmail = editItems.data.orgAltEmail;
     this.Carin_Bio_Url = editItems.data.carin_Bio_Url;

     if(editItems.errorMessage==null){
       this.isLoading = false;
       this.isEditProfileGet = true;

     }
     
     console.log("city " +this.city);

    })
  }


  callPostProfileMgmtEditService(
    )
    {
      this.editwaiting =true;
      this.Oid = "253c819a-7edf-46c9-b669-dbabc409f9fe";

      this.urlPatch = environment.urlEditPostProfile+this.data;

      const editAppData:DeveloperOrgRegModel = {

        
        Password:null,
        DisplayName :null,
        FirstName :null,
        Lastame :null,
        EMail :null,
        StreetAddress :this.EditStreetAddress,
       City :this.Editcity,
        State :this.EditState,
       Country :this.EditCountry,
        ZipCode :this.EditZipCode,
       PhoneNumber :this.EditPhone,
       OrganizationName:this.EditOrgName,
       OrganizationTaxID :this.EditOrgTaxID,
       OrgStreetAddress :this.EditOrgStreet,
       OrgCity :this.EditOrgCity,
       OrgState :this.EditOrgState,
       OrgCountry :this.EditOrgCountry,
       OrgZipCode :this.EditOrgZipCode,
        OrgAltEmail :this.OrgAltEmail,
        QuesIDs:null,
        CheckedTerms:false,
        CheckedCodeConduct:false,
        OrgID:this.ProfileData.orgID,
        Carin_Bio_Url:null,
  Policy_Url :null,
  InformationSecurityPolicy:false,
  OrgPhoneNumber:this.OrgPhoneNumber,
 


        
      };

      return this.http.patch<LoginResponseModel>(this.urlPatch,editAppData).
      subscribe(editResponseData=>{
       // this.editPostResponseData = editResponseData;
       console.log(editResponseData);
       if(editResponseData.statusCode == "Created")
       {
         this.editwaiting = false;
         this.editSuccesfullMsg = true;
       }
       
        
      })
    }
  

    onResetPassword(){
   
      window.location.href=environment.urlForgotnResetPwd;
    }

    onDeleteProfile(){
      // this.isDeleting = true;
      // this.appId = id;
     // message ='Do you want to really delete?';
    
     this.Oid = "eafc5219-4d97-4887-b354-7ae20c5d98ac";
     
     this.urlDelete =  environment.urlDelete+this.data;
     console.log("urlDelete "+ this.urlDelete);
     return this.http.delete<ProfileMgmtResponseModel>(this.urlDelete).subscribe(deleteapps=>{
       console.log(deleteapps);
       if(deleteapps)
       {
         this.deleteFail = false;
         this.isEditProfileGet = false;
         this.deleteSuccess = true;
         this.router.navigate(['landing']);

       }
       else{
        this.deleteSuccess = false;
         this.deleteFail = true;
       }
    
     })
    }

}
