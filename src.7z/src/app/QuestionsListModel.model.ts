import { Questions } from "./Questions.model";

export interface QuestionsListModel
    {
        errorMessage:string;
        statusCode:string;
        data:Questions[];
    }