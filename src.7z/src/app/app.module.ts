import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { WelcomeHeaderComponent } from './welcome-header/welcome-header.component';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppManagementComponent } from './app-management/app-management.component';
import { EditAppComponent } from './edit-app/edit-app.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProfileMgmtComponent } from './profile-mgmt/profile-mgmt.component';
import { LogoutComponent } from './logout/logout.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { GettingStartedComponent } from './getting-started/getting-started.component';
import { ResourcesComponent } from './resources/resources.component';
import { DialogComponent } from './dialog/dialog.component'
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { PoliciesCheckComponent } from './policies-check/policies-check.component';
import { SignupComponent } from './signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    WelcomeHeaderComponent,
    RegistrationComponent,
    AppManagementComponent,
    EditAppComponent,
    PageNotFoundComponent,
    ProfileMgmtComponent,
    LogoutComponent,
    LandingPageComponent,
    GettingStartedComponent,
    ResourcesComponent,
    DialogComponent,
    PoliciesCheckComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
      ConfirmationPopoverModule.forRoot({
        confirmButtonType: 'danger', // set defaults here
      }),
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
