export interface Questions
    {
        id:string;
        questionText:string;
       
    }