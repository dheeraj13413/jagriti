import { HttpClient } from '@angular/common/http';
import { isNgTemplate, ThrowStmt } from '@angular/compiler';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { timeStamp } from 'console';
import { create } from 'domain';
import { AppResponseModel } from '../AppResponseModel.model';
import { DialogService } from '../dialog/dialog.service';
import { ResponseModel } from '../ResponseModel.model';
import { RecreateSecretModel } from '../RecreateSecretModel.model';
import { DataStorageService } from '../shared/data-storage.service';
import { environment } from 'src/environments/environment.prod';


@Component({
  selector: 'app-app-management',
  templateUrl: './app-management.component.html',
  styleUrls: ['./app-management.component.css']
})
export class AppManagementComponent implements OnInit {
  loadedApps: AppResponseModel[] = [];
  loadedAppsAfterDeletion: AppResponseModel[] = [];
  appId: string = "";
  uoid: string = "21a13f14-9df0-43aa-b1ab-ea6cc3afbcf8";
  urlDelete = "";
  popoverTitle = 'Confirmation For Deletion';
  popoverMessage = "";
  //message ='Do you want to really delete?';

  confirmClicked = false;
  cancelClicked = false;
  isDeleting = false;
  urlCreateSecret = "";
  appIdForDelete = "";
  appName: string = "";
  clntId: string;
  recreatesecret = false;
  createsecretClientID: string = "";
  appslist = false;
  displayNme = "";
  isLoading = true;
  fetchError = false;
  recreateWait = false;


  constructor(private dataStorageService: DataStorageService,
    private http: HttpClient, private route: ActivatedRoute,
    private router: Router, public dialog: DialogService) { }
     data:string = sessionStorage.getItem('id');
     urlFetchListApps =  environment.urlFetchListApps+this.data+"/applications";

  ngOnInit(): void {

   
    if (this.data != null) {
      console.log("session id " + this.data);


      this.onFetchListApps().subscribe(
        (apps) => {

          console.log(apps);
          if (apps.errorMessage == "null") {





            apps.data.forEach(x => {
              //       //x.web.redirectUris =  [] ;

              //      x.web.uri = x.web.redirectUris.toString();
              x.web.uri = x.web.redirectUris.join();
              console.log(x.web.uri);
              console.log(x);
              // this.appId = x.id;

              this.appIdForDelete = x.id;
              console.log("appForDelete " + this.appIdForDelete);
              this.loadedApps.push(x);





              //this.loadedApps = apps;
              //console.log(this.loadedApps[0]);

            });
            this.fetchError = false;
            this.appslist = true;
            this.isLoading = false;

          }
          else {
            this.fetchError = true;
            this.appslist = false;
            this.isLoading = false;
          }

        })




    }
    else {
      this.router.navigate(['landing']);
    }
  }


  onEditAppItem(id: string) {
    //this.appId = this.loadedApps[index].id;

    //   this.loadedApps.forEach(z=>{
    // if(z.id == id)
    // {
    //   this.appId = id;
    // }

    //   })
    this.appId = id;
    // this.router.navigate(['/edit-app']);
    this.router.navigate(['edit-app']);






    // .subscribe(apps=>{
    //   console.log(apps);
    // })

  }

  getAppId(name: string) {
    this.appName = name;
    console.log("app in getAppId " + this.appName);
    this.popoverMessage = 'Do you want to really delete app ' + this.appName;
  }

  onDeleteApp(id: string) {
    this.isDeleting = true;
    this.appId = id;
    // message ='Do you want to really delete?';

    console.log("appId in delete " + this.appId);

    this.urlDelete =  environment.urlDelete+ this.data + "/applications/" + this.appId;
    console.log("urlDelete " + this.urlDelete);
    return this.http.delete<ResponseModel>(this.urlDelete).subscribe(deleteapps => {
      console.log(deleteapps);



      this.onFetchListApps().subscribe(
        (apps) => {

          console.log(apps);
          this.loadedApps = [];
          apps.data.forEach(x => {
            //       //x.web.redirectUris =  [] ;

            //      x.web.uri = x.web.redirectUris.toString();
            x.web.uri = x.web.redirectUris.join();
            console.log(x.web.uri);
            console.log(x);
            // this.appId = x.id;



            this.loadedApps.push(x);
            console.log("loadedApps " + this.loadedApps);

            this.isDeleting = false;


            //this.loadedApps = apps;
            //console.log(this.loadedApps[0]);

          });

        })






    });



  }


  onCreateRecreateSecret(id: string, clientId: string, displayName: string) {
    this.recreateWait = true;

    this.appId = id;
    this.clntId = clientId;
    this.displayNme = displayName;
    console.log("appId in createsecret " + this.appId);
    this.urlCreateSecret = environment.urlCreateSecret + this.data + "/applications/" + this.appId + "/addpassword";
    console.log("urlCreateSecret " + this.urlCreateSecret);
    return this.http.post<RecreateSecretModel>(this.urlCreateSecret, null).subscribe(createsecret => {
      console.log(createsecret);
      this.createsecretClientID = createsecret.data;
      if (createsecret.errorMessage == null) {
        this.recreateWait = false;
        this.recreatesecret = true;
        this.appslist = false;
      }
    })

  }


  async openDeleteConfirmation() {
    if (await this.dialog.confirm('Really open the Angular docs?')) {
      window.open('https://angular.io/docs')
    }
  }

  setFlag() {
    this.recreatesecret = false;
    this.appslist = true;

  }

  // remove(id:string){
  // this.loadedApps.filter(item->item.appId == id)
  // }


  onFetchListApps(){
   console.log("urlFetech "+this.urlFetchListApps);
    return  this.http.get<ResponseModel>(
      this.urlFetchListApps
    //  'https://run.mocky.io/v3/a4a5463f-1ba0-4060-9371-d2ac1fd599b9'
          ) 
        
          
         
    }
}
