import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';
import { DataStorageService } from '../shared/data-storage.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

  UserName= "";
  Password= "";
  errorMsg=false;

  constructor(private dataStorageService: DataStorageService, private router: Router) { }

  ngOnInit(): void {

    sessionStorage.setItem('id',"abc");

  }
  onNavigate(){
   
    window.location.href="https://b2cbcbsricmsdevportaldev.b2clogin.com/b2cbcbsricmsdevportaldev.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1_developerportal_signinup&client_id=2ff53c98-c76b-4a77-a6e2-8583bb0084be&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fazapp-eus2-dev-cms-developerportal.azase-eus2-dev-001.appserviceenvironment.net%2Fwelcome&scope=openid&response_type=code&prompt=login";
  }


 


  onVerifyLoginCredentials(){
    
  this.dataStorageService.onVerifyCredentials(this.UserName,this.Password).subscribe(responseData =>{
  
    console.log("responseData "+responseData);
    
    if(responseData.errorMessage!=null)
    {
      this.errorMsg = true;
    }
    else{
      
      this.router.navigate(['welcome']);
    }
    sessionStorage.setItem('id',responseData.data)
    var data = sessionStorage.getItem('id');
    console.log("session id "+data);
    localStorage.setItem('oid',responseData.data)
    var oid = localStorage.getItem('oid');
    console.log("oid " +oid);
  })
  


  }

  onForgetPassword(){
   
    window.location.href= environment.urlForgotnResetPwd;
  }

}
