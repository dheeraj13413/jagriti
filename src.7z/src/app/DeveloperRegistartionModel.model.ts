export interface DeveloperRegistartionModel
    {
         Password:string;
         DisplayName :string;
         FirstName :string;
         Lastame :string;
         EMail :string;
         StreetAddress :string;
        City :string;
         State :string;
        Country :string;
         ZipCode :string;
        PhoneNumber :string;
        otp?: string;
       
        
      
    }