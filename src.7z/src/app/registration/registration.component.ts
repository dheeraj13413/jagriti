import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControlName, NgForm } from '@angular/forms';
import { ResponseModel } from '../ResponseModel.model';
import { Registration } from '../Registration.model';



import { DataStorageService } from '../shared/data-storage.service';
import { AppResponseModel } from '../AppResponseModel.model';
import { ResponseModelForRgtr } from '../ResponseModelForRgtr.model';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment.prod';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
//url:File = null;
url = "";
checkedProduction="";
checkedNonProduction="";
checkedPolicy:boolean;
checkedTerms:boolean;
checkedCodeConduct:boolean; 
redirectUri:string = "";
redirectUriArrays :string[]= this.redirectUri.split(',');
isRegistrating = false;
clientSecretFromRegisterRes = "";
responsedataClientId= "";
responsedataClientSecret = ""

array:Uint8Array;
 BASE64_MARKER = ';base64,';
 urltest = "";
 finalUrlValue = "";

 ApplicationName = "";
 isRegistrationInputForm = true;
 isRegistrationComplete = false;
 image = "";
 convertImage = "";
 redirectUrls = "";
 Application_Purpose= "";
 Application_Type= "";
  suucessfullMsg="";
  successfulltypemsg = "";
  urlRegister: string;
  imgAreaVisible= false;



  
  constructor(private dataStorageService: DataStorageService,private http:HttpClient,
    private router: Router) { }
     data:string = sessionStorage.getItem('id');
    
     
  ngOnInit(): void {
    
    if(this.data!= null){
      console.log("session id "+this.data);
      this.router.navigate(['registration']);

    
  }
  else{
    this.router.navigate(['landing']);

  }
}


  onFileSelect(e:any){
    if(e.target.files)
    {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload=(event:any)=>{
        this.url = event.target.result;
         /*for making image boundry visible only after selection of image*/ 
         this.imgAreaVisible = true;
        this.convertImage = this.url;
       
        console.log("url" +this.convertImage);
      
      //  this.convertDataURIToBinary(this.url);

//         let b64Data = this.url.split(',', 2)[1];
//  var byteArray =  new Buffer(b64Data ,'base64').toString();
//   this.blob = new Blob([byteArray]);
        //console.log("url "+this.blob);
      }
    }

  }
  
  // convertDataURIToBinary(dataURI) {
  //   var base64Index = dataURI.indexOf( this.BASE64_MARKER) +  this.BASE64_MARKER.length;
  //   var base64 = dataURI.substring(base64Index);
  //   var raw = window.atob(base64);
  //   var rawLength = raw.length;
  //   this. array = new Uint8Array(new ArrayBuffer(rawLength));
  
  //   for(let i = 0; i < rawLength; i++) {
  //     this.array[i] = raw.charCodeAt(i);
  //   }
  //   console.log("array "+this.array);
  //   return this.array;
  // }

  productionClicked(value:string){
    this.checkedProduction = value;
    console.log("checkedPolicy value" ,this.checkedProduction);
  }

  NonproductionClicked(value:string){
    this.checkedNonProduction = value;
    console.log("checkedPolicy value" ,this.checkedNonProduction);
  }

  

  checkboxPolicyClicked(value:boolean){
    this.checkedPolicy = value;
    console.log("checkedPolicy value" ,this.checkedPolicy);
  }

  checkboxTermsClicked(value:boolean){
    this.checkedTerms = value;
    console.log("checkedTerms value" ,this.checkedTerms);
  }

  checkboxCodeConductClicked(value:boolean){
    this.checkedCodeConduct = value;
    console.log("checkedCodeConduct value" ,this.checkedCodeConduct);
  }

  
  
  OnRegister(registerData:Registration){

    this.isRegistrating = true;
     this.finalUrlValue = this.url.substring(22);
     this.successfulltypemsg = this.checkedProduction==='option1'?'Production':'NonProduction';
     this.urlRegister = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/"+this.data+"/applications";
     console.log("data "+this.data);
    

    // const fd = new FormData();
    // fd.append('image',this.url);
    
    
    
    
this.dataStorageService.onAppRegister(registerData.ApplicationName,registerData.RedirectUrls.toString().split(','),
 registerData.logo= null ,registerData.Uoid = this.data,registerData.ImageBase64=this.finalUrlValue,
 registerData.Application_Type = this.checkedProduction==='option1'?'Production':'NonProduction',registerData.Application_Purpose,
 registerData.urlRegister = environment.urlRegister +this.data+"/applications")
  .subscribe(responseData =>{
  
    
      console.log(responseData);
      this.responsedataClientId=responseData.body.data.clientId;
      this.responsedataClientSecret=responseData.body.data.clientSecret;
    console.log("responseData "+responseData);
    console.log("responseData 0 "+responseData.body.data.clientId);
    console.log("responseData 0 "+responseData.body.data.clientSecret);
    this.suucessfullMsg= "Registration has been succesfully completed with "+this.successfulltypemsg+" details.";
  
    if(responseData.body.errorMessage == null){
      
      this.isRegistrationInputForm = false;
      this.isRegistrating = false;
      this.isRegistrationComplete = true;

      // alert("Your app "+ this.clientSecretFromRegisterRes+ " is registered succesfully.Thanks!!!")
    }
    // else{
    //   alert("There is an error while registration of your app.Please Try Again")
    // }

  
  
});
  

  }

  setFlag(){
    this.isRegistrationInputForm = true;
    this.isRegistrating = false;
    this.isRegistrationComplete = false;

  }


//   testApiCall(){
   

//     this.urltest =  "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/testaddapp";
//     console.log("urlCreateSecret "+ this.urltest);
//     var finalUrl = this.url.substring(22);
//     const testData:Testpurpose = {base64Stringimg:finalUrl};
//     return this.http.post<Testpurpose>(this.urltest,testData).subscribe(test=>{
//       console.log(test);
//      })

// }
}
