import { trigger, style, animate, transition } from '@angular/animations';


export const dialogAnimation = (enterDuration, leaveDuration) => trigger(

  'dialogAnimation',
  [
    transition(':enter', [
      style({ opacity: 0 }),
      animate(`${enterDuration}s`, style({ opacity: 1 }))
    ]),
    transition(':leave', [
      style({ opacity: 1 }),
      animate(`${leaveDuration}s`, style({ opacity: 0 }))
    ])
  ]
  
);