import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DialogService } from './dialog.service';
import { dialogAnimation } from './dialog-animation';


@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css'],
  animations: [ dialogAnimation(0.2, 0.5) ]
})
export class DialogComponent  {

  buttonConfig = [
    {value: true, text: 'Yes, please!', background: 'green'},
    {value: false, text: 'No, thanks.', background: 'red'}
  ]

  constructor(public dialog: DialogService) {}

  onClose(isConfirmed: boolean) {
    this.dialog.closed.next(isConfirmed);
  }

}
