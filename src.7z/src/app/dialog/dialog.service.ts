import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { first, delay, finalize } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DialogService {

  message = '';
  closed = new Subject<boolean>();
  fadeOutTime = 500;
  backdropTopPx: number;


  confirm(message) {

    this.openDialog(message);

    return this.closed
      .pipe(
        first(), 
        finalize(this.closeDialog),
        delay(this.fadeOutTime)
      )
      .toPromise()   

  }


  private openDialog(message) {

    this.message = message;
    this.backdropTopPx = window.scrollY;
    document.body.style.overflowY = 'hidden';

  }


  private closeDialog = () => {

    this.message = '';
    setTimeout(() => document.body.style.overflowY = 'auto', this.fadeOutTime);
    
  }

}