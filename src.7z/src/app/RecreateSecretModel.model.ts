export interface RecreateSecretModel
{
data:string;
errorMessage:string;
status:string;

}