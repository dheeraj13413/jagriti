import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private router: Router) { }
  data:string;
  ngOnInit(): void {
    this.data = sessionStorage.getItem('id');
    if(this.data!=null){
     // this.data = "";
      sessionStorage.setItem('id',"abc")
      this.data =sessionStorage.getItem('id')
      console.log("data "+this.data);
      this.router.navigate(['landing']);
    }
  }

}
