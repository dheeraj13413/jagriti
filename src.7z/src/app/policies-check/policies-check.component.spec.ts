import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoliciesCheckComponent } from './policies-check.component';

describe('PoliciesCheckComponent', () => {
  let component: PoliciesCheckComponent;
  let fixture: ComponentFixture<PoliciesCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoliciesCheckComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoliciesCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
