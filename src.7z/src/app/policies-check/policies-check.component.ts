import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policies-check',
  templateUrl: './policies-check.component.html',
  styleUrls: ['./policies-check.component.css']
})
export class PoliciesCheckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
