import { AppResponseModel } from "./AppResponseModel.model";

export interface ResponseModelForRgtr
    {
        errorMessage : string ;
        statusCode :  string ;
        data  :AppResponseModel;
      
    }
