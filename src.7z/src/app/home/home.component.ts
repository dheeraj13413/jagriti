import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 

  constructor( ) { 
    location.href = 'https://b2cbcbsricmsdevportaldev.b2clogin.com/b2cbcbsricmsdevportaldev.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1_developerportal_signinup&client_id=2ff53c98-c76b-4a77-a6e2-8583bb0084be&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fazapp-eus2-dev-cms-developerportal.azase-eus2-dev-001.appserviceenvironment.net%2Fwelcome&scope=openid&response_type=code&prompt=login';
  }

  ngOnInit(): void {
  }

  // onNavigate(){
  //   const url ="https://www.google.com/";
  //   window.open(url, '_blank');
  // }

  // onNavigate(){
   
  //   window.location.href="https://bcbsrib2cisolated.b2clogin.com/BCBSRIB2CIsolated.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1_cmsinterop_devportal_signupin&client_id=5d38be0b-af56-4a45-8f9c-639fcd28ca69&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fapp-poc-developerportal.ase-poc-common.appserviceenvironment.net%2Fwelcome&scope=openid&response_type=id_token&prompt=login";
  // }

}
