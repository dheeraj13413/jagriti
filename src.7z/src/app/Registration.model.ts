export interface Registration
{
 ApplicationName :string;
 RedirectUrls:string[];
//  PrivacyPolicy :boolean;
//  TOSAttestation :boolean;
//  CodeOfConductAttestation  :boolean;
  logo :Blob;
 Uoid :string ;
 ImageBase64:string;
 Application_Type :string;
 Application_Purpose :string;
 urlRegister?:string;
}
// we are adding ingredients here for the functionality of showing 
//ingredients in recipe details section

// constructor(ApplicationName:string,RedirectUrls:string,PrivacyPolicy:string,TOSAttestation:string,
//     CodeOfConductAttestation:string,logo:[],IDToken:string)
// {
//     this.ApplicationName = ApplicationName;
//     this.RedirectUrls = RedirectUrls;
//     this.PrivacyPolicy = PrivacyPolicy;
//     this.TOSAttestation = TOSAttestation;
//     this.CodeOfConductAttestation  = CodeOfConductAttestation ;
//     this.logo = logo;
//     this.IDToken = IDToken;
   
// }


