import { NgModule } from '@angular/core';
import { Routes, RouterModule, ChildrenOutletContexts } from '@angular/router';
import { AppManagementComponent } from './app-management/app-management.component';
import { EditAppComponent } from './edit-app/edit-app.component';
import { GettingStartedComponent } from './getting-started/getting-started.component';
import { HomeComponent } from './home/home.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LogoutComponent } from './logout/logout.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PoliciesCheckComponent } from './policies-check/policies-check.component';
import { ProfileMgmtComponent } from './profile-mgmt/profile-mgmt.component';
import { RegistrationComponent } from './registration/registration.component';
import { ResourcesComponent } from './resources/resources.component';
import { WelcomeHeaderComponent } from './welcome-header/welcome-header.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
 {path:'', redirectTo:'/landing',pathMatch:'full'},
 {path:'landing',component:LandingPageComponent},
 {path:'started',component:GettingStartedComponent},
 {path:'resources',component:ResourcesComponent},
  {path:'home', component:HomeComponent},
  {path:'policies', component:PoliciesCheckComponent},
  {path:'welcome', component:WelcomeHeaderComponent},
  {path:'registration', component:RegistrationComponent},
  {path:'app-mgmt',component:AppManagementComponent}, 
  {path:'edit-app/:id',component:EditAppComponent},
  {path:'profile-mgmt',component:ProfileMgmtComponent},
  {path:'signup',component:SignupComponent},
  {path:'logout',component:LogoutComponent},
  {path:'**',component:PageNotFoundComponent},
  


//   children:[
//   {path:'edit-app',component:EditAppComponent}
//   ]
// }
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
