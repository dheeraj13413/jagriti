export interface OrganizationRegistartionModel
    {
        OrganizationName:string;
        OrganizationTaxID :string;
         OrgStreetAddress :string;
         OrgCity :string;
         OrgState :string;
         OrgCountry :string;
         OrgZipCode :string;
         OrgAltEmail :string;
         Carin_Bio_Url :string,
  Policy_Url :string;
  InformationSecurityPolicy:boolean;
  OrgPhoneNumber:string;





       
        
      
    }