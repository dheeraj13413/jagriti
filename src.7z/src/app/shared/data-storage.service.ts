import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Registration } from '../Registration.model';
import { map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { Key } from 'protractor';
import { ResponseModel } from '../ResponseModel.model';
import { ResponseModelForRgtr } from '../ResponseModelForRgtr.model';
import { rmdir } from 'fs';

import { LoginResponseModel } from '../LoginResponseModel.model';
import { credentialsModel } from '../credentialsModel.model';

import { DeveloperOrgRegModel } from '../DeveloperOrgRegModel.model';

import { CodeVerificationModel } from '../CodeVerificationModel.model';
import{SignupResponseModel} from '../SignupResponseModel.model';
import{environment} from '../../environments/environment.prod';
import { FormGroup } from '@angular/forms';


@Injectable({providedIn:'root'})
export class DataStorageService{
  
   data = sessionStorage.getItem('id');
 
    uoid:string ="21a13f14-9df0-43aa-b1ab-ea6cc3afbcf8";

   // urlRegister = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/"+this.uoid+"/applications";

   // urlRegister = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/"+localStorage.getItem('oid')+"/applications";
  //  urlFetchListApps =  "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/application/developer/"+localStorage.getItem('oid')+"/applications";
    urlProfileRegister = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/developers";
  urlVerifyCode="https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/communication/code";
    urlLogincheck = "https://azapp-eus2-dev-cms-developerportalservice.azase-eus2-dev-001.appserviceenvironment.net/api/v1/developer/signin";
    

    constructor(private http:HttpClient){}


    

    onAppRegister(ApplicationName:string,RedirectUrls:string[],
    logo:Blob,Uoid:string,ImageBase64:string,Application_Type:string,Application_Purpose:string,urlRegister:string){
            const registerData:Registration = {ApplicationName:ApplicationName,
                RedirectUrls:RedirectUrls,logo:logo,Uoid:Uoid,ImageBase64:ImageBase64,Application_Type:Application_Type,Application_Purpose:Application_Purpose,
                urlRegister:urlRegister};
                console.log("data in service "+this.data);
                console.log("urlRegister "+urlRegister);
                console.log("session "+sessionStorage.getItem('id'));
                console.log("local "+localStorage.getItem('oid'));
      return  this.http.post<ResponseModelForRgtr>(
        urlRegister
            ,registerData,
            {
                headers:new HttpHeaders({'custom-header':'Hello'}),
                observe:'response'
            }
            )

          
     
    }

    // onFetchListApps(){
   
    //   return  this.http.get<ResponseModel>(
    //     this.urlFetchListApps
    //   //  'https://run.mocky.io/v3/a4a5463f-1ba0-4060-9371-d2ac1fd599b9'
    //         ) 
          
            
           
    //   }

      onProfileRegister(Password:string,DisplayName :string,FirstName :string,Lastame :string,
        EMail :string,StreetAddress :string,City :string,State :string,Country :string,
        ZipCode :string,PhoneNumber :string,OrganizationName:string,
        OrganizationTaxID :string, OrgStreetAddress :string,OrgCity :string,OrgState :string,
        OrgCountry :string,OrgZipCode :string,
        OrgAltEmail :string,QuesIDs:number[], CheckedTerms:boolean,
        CheckedCodeConduct:boolean,Carin_Bio_Url :string,
        Policy_Url :string,InformationSecurityPolicy:boolean,OrgPhoneNumber:string){
                const registerData:DeveloperOrgRegModel = {Password:Password,
                  DisplayName:DisplayName,FirstName:FirstName,Lastame:Lastame,EMail:EMail,
                      StreetAddress:StreetAddress,City:City,State:State,Country:Country,
                  ZipCode:ZipCode,PhoneNumber:PhoneNumber,OrganizationName:OrganizationName,
                  OrganizationTaxID:OrganizationTaxID,OrgStreetAddress:OrgStreetAddress,
                  OrgCity:OrgCity,OrgState:OrgState,OrgCountry:OrgCountry,OrgZipCode:OrgZipCode,
                  OrgAltEmail:OrgAltEmail,QuesIDs:QuesIDs,CheckedTerms:CheckedTerms,CheckedCodeConduct:CheckedCodeConduct,
                  Carin_Bio_Url :Carin_Bio_Url,
                  Policy_Url :Policy_Url,InformationSecurityPolicy:InformationSecurityPolicy,
                  OrgPhoneNumber:OrgPhoneNumber};
                  
    
          return  this.http.post<SignupResponseModel>(
            environment.urlProfileRegister
                ,registerData,
                {
                    headers:new HttpHeaders({'custom-header':'Hello'}),
                    observe:'response'
                }
                )
    
              
         
        }

        onVerifyCode(EmailAddress:string,Code:string){

          console.log("emailurl "+this.urlVerifyCode);
          const emailData:CodeVerificationModel = {EmailAddress:EmailAddress,Code:Code};
          return  this.http.post(
            environment.urlVerifyCode,emailData
               
                )
        
        }

        onVerifyCredentials(UserName:string, Password:string){

          const loginData:credentialsModel ={UserName:UserName,Password:Password};
          return  this.http.post<LoginResponseModel>(
            environment.urlLogincheck,loginData
               
                )



        }

       

     


            // .pipe(
            //   map((responseData:ResponseModel,index:number)=> {
            //      responseData.data.forEach(x =>{
            //       //x.web.redirectUris =  [] ;
                  
            //     //  x.web.uri = x.web.redirectUris.toString();
            //       x.web.uri = x.web.redirectUris.join();
            //       console.log(x.web.uri);
            //       console.log(x);
            //       console.log(responseData.data);
                  
            //     })
            //   })
            
            // )
            


            // .pipe(
            //   map((responseData:ResponseModel,index:number)=> {
            //     return responseData.data.forEach((x,index:number) =>{
            //       x.web.redirectUris =  [] ;
            //       x.web.uri = x.web.redirectUris.join();
            //     })
            //   })
            
            // )




            // .pipe(
            //   map((response:any )=> {
            //     return response.map((test:ResponseModel,index:number)=>{
            //       return {...test,
            //          web:test.data[index].web.redirectUris.toString()
            //       };
            //     });
            //   })
            
            // )






            // .pipe(
            //         map(responseData => {
            //           const postsArray:ResponseModel[] = [];
                      
            //           for (const key in responseData) {
                       
            //             if (responseData.hasOwnProperty(key)) {
            //               postsArray.push({...responseData})
            //             }
            //           }
                      
            //           return postsArray;
            //         })
                    
            //       )
      
    



    




}