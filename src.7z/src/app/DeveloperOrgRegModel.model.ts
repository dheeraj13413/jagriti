import { OrganizationRegistartionModel } from "./OrganizationRegistartionModel.model";
import { DeveloperRegistartionModel } from './DeveloperRegistartionModel.model';

export interface DeveloperOrgRegModel
    {
     //     DeveloperReg : DeveloperRegistartionModel;
     //     OrganizationReg:OrganizationRegistartionModel;


         Password:string;
         DisplayName :string;
         FirstName :string;
         Lastame :string;
         EMail :string;
         StreetAddress :string;
        City :string;
         State :string;
        Country :string;
         ZipCode :string;
        PhoneNumber :string;
        OrganizationName:string;
        OrganizationTaxID :string;
        OrgStreetAddress :string;
        OrgCity :string;
        OrgState :string;
        OrgCountry :string;
        OrgZipCode :string;
         OrgAltEmail :string;
         QuesIDs:number[];
         CheckedTerms:boolean;
         CheckedCodeConduct:boolean;
         OrgID?:number;
         Carin_Bio_Url :string;
  Policy_Url :string;
  InformationSecurityPolicy:boolean;
  OrgPhoneNumber:string;



    }