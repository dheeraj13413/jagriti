export interface ProfileMgmtResponseModel
{
data:boolean;
errorMessage:string;
status:string;

}