import { Countries} from "./Countries.model";

export interface CountryListModelResponse
    {
        errorMessage:string;
        statusCode:string;
        data:Countries[];
    }