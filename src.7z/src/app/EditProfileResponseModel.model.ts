import { EditProfileDataResponseModel } from "./EditProfileDataResponseModel.model";

export interface EditProfileResponseModel
    {
       
        // constructor(public errorMessage: string, public statusCode: string, public data:AppResponseModel[])
        //  {

        //  }
        errorMessage : string ;
        statusCode :  string ;
        data  :EditProfileDataResponseModel;
        
      
    }