export interface EmailAddressSentModel
    {
        EmailAddress:string;
       


    }