import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERDentalInactiveTableComponent } from './perdental-inactive-table.component';

describe('PERDentalInactiveTableComponent', () => {
  let component: PERDentalInactiveTableComponent;
  let fixture: ComponentFixture<PERDentalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERDentalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERDentalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
