import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-nav-test',
  templateUrl: './side-nav-test.component.html',
  styleUrls: ['./side-nav-test.component.css']
})
export class SideNavTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
