import { Component, OnInit } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: 'app-per-medical-form',
  templateUrl: './per-medical-form.component.html',
  styleUrls: ['./per-medical-form.component.css']
})
export class PerMedicalFormComponent implements OnInit {

  public disableField: boolean = true;

  constructor(
    public router: Router
  ) { }

  ngOnInit(): void {
  }

  onClose(){
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onEdit(){
    this.disableField = false;
  }

  onDelete(){
    // call delete API of perticular row
    alert("Deleted Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onUpdate(){
    // call update API with perticular row data
    alert("Updated Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }



}
