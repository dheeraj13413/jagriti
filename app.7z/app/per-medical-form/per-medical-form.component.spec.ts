import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerMedicalFormComponent } from './per-medical-form.component';

describe('PerMedicalFormComponent', () => {
  let component: PerMedicalFormComponent;
  let fixture: ComponentFixture<PerMedicalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerMedicalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PerMedicalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
