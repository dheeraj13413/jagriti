import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DPMedicalActiveTableComponent } from './dpmedical-active-table.component';

describe('DPMedicalActiveTableComponent', () => {
  let component: DPMedicalActiveTableComponent;
  let fixture: ComponentFixture<DPMedicalActiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DPMedicalActiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DPMedicalActiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
