import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-admin',
  templateUrl: './app-admin.component.html',
  styleUrls: ['./app-admin.component.css']
})
export class AppAdminComponent implements OnInit {

  public showForClick: boolean = false;
  public  currentURL: string = null;

  constructor() { }

ngOnInit(): void {
  this.currentURL = window.location.href;

   if (this.currentURL === "http://localhost:4200/admin") {
      this.showForClick = true;
    } else {
      this.showForClick = false;
    }

    console.log("ShowData :"+this.showForClick);
  }

}
