export class ParConstants
    {
        public static parentGroupID : string = "parentGroupID";
        public static groupID : string = "groupID";
        public static medicalProductID : string = "medicalProductID";
        public static visionProductID : string = "visionProductID"
        public static pharmacyProductID : string = "pharmacyProductID";
        public static dentalProductID : string = "dentalProductID";
        public static restore : string = "restore";

        public static parentId : string = "parentId";
        public static groupId : string = "groupId";
        public static healthProductId : string = "healthProductId";
        public static visionId : string = "visionId";
        public static pharmacyId : string = "pharmacyId";
        public static startDate : string = "startDate";
        public static endDate : string = "endDate";
        public static attachmentName : string = "attachmentName";  
        public static description : string = "description";
        public static effectiveDate : string = "effectiveDate";

        //data constants
        public static Azure : string = "Azure";
        public static StatusActive : string = "Active";
        public static StatusArchive : string = "Archive";
        public static StatusInactive : string = "Inactive";
        public static DocNeededN : string = "N";
        public static IERGroup : string = "IER";
        public static DPGroup : string = "DP";
        public static DProduct : string = "D";   
        public static MProduct : string = "M";

        public static gsaURL : string = "https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/GSA";

    }