import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IERMedicalFormComponent } from './iermedical-form.component';

describe('IERMedicalFormComponent', () => {
  let component: IERMedicalFormComponent;
  let fixture: ComponentFixture<IERMedicalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IERMedicalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IERMedicalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
