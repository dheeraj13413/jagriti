import { Component, OnInit } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from "@angular/router";
import { FormsDropDownResModel } from '../model/FormsDropDownResModel';
import { EditReqModel } from '../model/EditReqModel';
import { EditResModel } from '../model/EditResModel';
import { FormsDrpDownList } from '../model/FormsDrpDownList';
import { DataStorageService } from '../service/data-storage.service';
import { ParConstants } from '../globalConstants/par-constants';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-iermedical-form',
  templateUrl: './iermedical-form.component.html',
  styleUrls: ['./iermedical-form.component.css']
})
export class IERMedicalFormComponent implements OnInit {

  public disableField: boolean = true;
  uniqueId:string;
  userID: string;
  isDocNeeded: string;
  agreementStatus: string;
  groupTypeFlag: string;
  productTypeFlag: string;
  myObj: any;
  errorMessage: string;
 // showErrorMsg: boolean = false;
 // showList: boolean = true;
  unid: string;
  public dataSource: MatTableDataSource<any>;
  paginator: any;
  parentGroupName: string;
  parentGroupId: string;
  repName: string;
  serviceRep: string;
  frontCover: string;
  amendments: string;
  assignedTo: string;
  startDate: string;
  endDate:string;
  groupRenewalDate: string;
  healthProductID: string;
  dentalProductId: string;
  version: string;
  visionProductId : string;
  pediDentalProductId: string;
  pharmacyProductId: string;
  workflowAssignedTo:string;
  workflowStatus: string;
  dateCompleted :string;
  completionDate: string;
  bcBase:string;
  bcMhsa: string;
  bsBase:string;
  bsMhsa:string;
  mm:string;
  ot:string;
  rx:string;
  stuBs:string;
  stuBc:string;
  depBs:string;
  depBc:string;
  visRout:string;
  visHw:string;
  acup:string;
  mhpAdmin:string;
  hear:string;
  prevAdmin:string;
  wcInst:string;
  wcBea:string;
  p65a:string;
  p65b:string;
  groupId: string;
  configurationID: number;
  keyType: string;
  ApiFunction: string;
  keyValue: any;
  dropDownData: FormsDropDownResModel;
  checkedDomestic: string;
  offCycle: string;
  functionType:string;
  adminFunction: string;
  loadedKeyValue: FormsDrpDownList[];
  abc: string;
  medicalProductId: string;
  pediVisionId: string;
  dateWithdrawn: string;
  groupName: any;
  repId: any;
  productLine: any;
  productFamily: any;
  domesticPartner: any;
  domesticPartnerGender: any;
  dependentStopRule: any;
  offCycleNumber: any;
  comments: any;
  productVarId: any;
  productVarIdDescription: any;
  benefitHighlight: any;
  agreementName: any;
  markDelete: any;
  editapiURL = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/uSA';
  status: string;
  subscriberAgreementType: any;
  showSucessMsg: boolean = false;
  errorDescription: boolean = false;
  errorMsg: string;
  showError: boolean = false;
  showForm:boolean = true;
  errorDescLoadData: string;
  
  constructor(
    private route : ActivatedRoute,
    private router: Router,
    private dataStorageService: DataStorageService,
    private http : HttpClient
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
  
      this.uniqueId = params.get('unid');
      this.status = params.get('status');
      console.log("uniqueId "+params.get('unid'));
      console.log("status "+params.get('status'));
      
      
    })
    this.onLoadFormData();
    this.selectProductFamily();
 // this.onClickOfSave();
  }


  onClose(){
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onEdit(){
    this.disableField = false;
  }

  onDelete(){
    // call delete API of perticular row
    alert("Deleted Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onUpdate(){
    // call update API with perticular row data
    alert("Updated Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onLoadFormData(){
    this.dataStorageService.onGetMedicalFormData(this.userID= 'Azure',
      this.isDocNeeded='N',
      this.agreementStatus='Active',
      this.groupTypeFlag= 'IER',
      this.productTypeFlag='M',
      this.unid = this.uniqueId
      ).subscribe(responseData =>{
        if(responseData.errorCode ==null ||responseData.errorCode =="")
        {
        this.parentGroupName = responseData.successResponse[0].parentGroupName;
        this.parentGroupId = responseData.successResponse[0].parentGroupId;
        this.repName = responseData.successResponse[0].repName;
        this.serviceRep = responseData.successResponse[0].serviceRep;
        this.frontCover = responseData.successResponse[0].frontCover;
        this.amendments = responseData.successResponse[0].amendments;
        this.assignedTo = responseData.successResponse[0].workflowAssignedTo;
        this.startDate = responseData.successResponse[0].effectiveStartDate;
        this.endDate = responseData.successResponse[0].effectiveEndDate;
        this.groupRenewalDate = responseData.successResponse[0].groupRenewalDate;
        this.healthProductID = responseData.successResponse[0].medicalProductId;
        this.dentalProductId = responseData.successResponse[0].dentalProductId;
        this.version = responseData.successResponse[0].version;
        this.visionProductId = responseData.successResponse[0].visionId;
        this.pediDentalProductId = responseData.successResponse[0].pediDentalProductId;
        this.pharmacyProductId = responseData.successResponse[0].pharmacyProductId;
        this.workflowAssignedTo = responseData.successResponse[0].workflowAssignedTo;
        this.workflowStatus =responseData.successResponse[0].workflowStatus;
        this.dateCompleted = responseData.successResponse[0].dateCompleted;
        this.completionDate = responseData.successResponse[0].completionDate;
        this.bcBase = responseData.successResponse[0].bcBase;
        this.bcMhsa = responseData.successResponse[0].bcMhsa;
        this.bsBase=responseData.successResponse[0].bsBase;
        this.bsMhsa = responseData.successResponse[0].bsMhsa;
        this.mm=responseData.successResponse[0].mm;
         this.ot =responseData.successResponse[0].ot;
         this.rx=responseData.successResponse[0].rx;
         this.stuBs =responseData.successResponse[0].stuBs;
         this.stuBc=responseData.successResponse[0].stuBc;
         this.depBs=responseData.successResponse[0].depBs;
         this.depBc=responseData.successResponse[0].depBc;
         this.visRout=responseData.successResponse[0].visRout;
         this.visHw=responseData.successResponse[0].visHw;
         this.acup=responseData.successResponse[0].acup;
         this.mhpAdmin=responseData.successResponse[0].mhpAdmin;
         this.hear =responseData.successResponse[0].hear;
         this.prevAdmin=responseData.successResponse[0].prevAdmin;
         this.wcInst=responseData.successResponse[0].wcInst;
         this.wcBea=responseData.successResponse[0].wcBea;
         this.p65a=responseData.successResponse[0].p65a;
         this.p65b=responseData.successResponse[0].p65b;
        this.groupId = responseData.successResponse[0].groupId;
        this.groupName = responseData.successResponse[0].groupName;
        this.checkedDomestic = responseData.successResponse[0].domesticPartner;
        this.offCycle = responseData.successResponse[0].offCycle;
        this.functionType = responseData.successResponse[0].fundingType;
        this.medicalProductId = responseData.successResponse[0].medicalProductId;
        this.pediVisionId = responseData.successResponse[0].pediVisionProductId;
        this.dateWithdrawn = responseData.successResponse[0].dateWithdrawn;
        this.repId = responseData.successResponse[0].repId;
        this.productLine = responseData.successResponse[0].productLine;
        this.productFamily = responseData.successResponse[0].productFamily;
        this.domesticPartner = responseData.successResponse[0].domesticPartner;
        this.domesticPartnerGender = responseData.successResponse[0].domesticPartnerGender;
        this.dependentStopRule = responseData.successResponse[0].dependentStopRule;
        this.offCycleNumber = responseData.successResponse[0].offCycleNumber;
        this.comments = responseData.successResponse[0].comments;
        this.productVarId= responseData.successResponse[0].productVarId;
        this.productVarIdDescription = responseData.successResponse[0].productVarIdDescription;
        this.benefitHighlight =  responseData.successResponse[0].benefitHighlight;
        this.agreementName = responseData.successResponse[0].agreementName;
        this.markDelete = responseData.successResponse[0].markDelete;
        this.subscriberAgreementType = responseData.successResponse[0].subscriberAgreementType;
        this.showError = false;

        
        console.log("subscAgTye "+this.subscriberAgreementType);



        }
       
else{
this.showForm = false;
  this.showError = true;
  this.errorDescLoadData = responseData.errorDescription;
  
}


        
        

      
    
      }
      );
  }

  selectProductFamily(){

    this.dataStorageService.onSelectDropDown(
      this.userID='CHNLSALES',
      this.configurationID=0,
      this.keyValue=null,
      this.keyType='Product Family',
      this.adminFunction='Get'
    
    ).subscribe(responseData =>{
     
  this.dropDownData = responseData;
//   console.log("data index "+this.dropDownData.data);
//  console.log("data "+this.dropDownData.data[0]);
//  console.log("data index "+this.dropDownData.data);

  this.dropDownData.data.forEach(x =>{
   this.keyValue = x.keyValue;
  //  this.countryName =  x.country_Name;
  //  this.id = x.id;
    this.loadedKeyValue.push(x);
   // console.log("loadedCountry "+this.loadedKeyValue);
    

 })

  console.log("resoponse from drop down: "+responseData);

})

  }

  onClickOfSave(){
const editAppData:EditReqModel =
 { UserID:ParConstants.Azure,
    Unid:this.uniqueId, 
    EffectiveStartDate :this.startDate,
    EffectiveEndDate:this.endDate, 
    DentalProductID :this.dentalProductId,
    MedicalProductID :this.medicalProductId,
    PharmacyProductID :this.pharmacyProductId,
    VisionProductID :this.visionProductId,
    PediDentalProductID :this.pediDentalProductId,
    PediVisionProductID :this.pediVisionId,
    WorkflowStatus :this.workflowStatus,
    WorkflowAssignedTo :this.workflowAssignedTo,
    DateWithdrawn :this.dateWithdrawn,
    ParentGroupID :this.parentGroupId,
    ParentGroupName :this.parentGroupName,
    GroupID :this.groupId,
    GroupName :this.groupName,
    FundingType :this.functionType,
    FrontCover :this.frontCover,
    RepName :this.repName,
    RepID :this.repId,
    ServiceRep :this.serviceRep,
    ProductLine :this.productLine,
    ProductFamily :this.productFamily,
    Version :this.version,
    DomesticPartner :this.domesticPartner,
    DomesticPartnerGender :this.domesticPartnerGender,
    OffCycle :this.offCycle,
    OffCycleNumber :this.offCycleNumber,
    DependentStopRule :this.dependentStopRule,
    Comments :this.comments,
    ProductVarID :this.productVarId,
    ProductVarIDDescription :this.productVarIdDescription,
BenefitHighlight:this.benefitHighlight, 
//SubscriberAgreementType :this.subscriberAgreementType,
MarkDelete :this.markDelete
    };
    return this.http.post(this.editapiURL,editAppData).
    subscribe((editResponseData:EditResModel)=>{
      if(editResponseData.responseStatus == "Success")
      {
         this.showSucessMsg = true;
          this.errorDescription = false;
      }
      else{
        this.showSucessMsg = false;
        this.errorDescription = true;
        this.errorMsg = editResponseData.errorDescription;

      }

      console.log("response "+editResponseData);
    })

  }


  onClickOfCancel(){

   if(this.status == "Active"){
      this.router.navigate(['/admin/ierMedicalActive']);
    } // navigate to other page
  else if(this.status == "Active") 
{
  this.router.navigate(['/admin/ierMedicalInactive']);
}
else{
  this.router.navigate(['/admin/ierMedicalArchive']);
}  
  }


  onClickOfDelete(){
    const deleteAppData =
     {
        UserID:ParConstants.Azure,
      markDelete:'N',
unid: this.uniqueId


     };
     return this.http.post(this.editapiURL,deleteAppData).
     subscribe(deleteResponseData=>{

      console.log("deleteResponse" +deleteResponseData);

     })
    }

}
