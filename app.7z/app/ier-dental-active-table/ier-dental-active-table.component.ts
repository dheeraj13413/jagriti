import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ParConstants } from '../globalConstants/par-constants';
import { DataStorageService } from '../service/data-storage.service';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-ier-dental-active-table',
  templateUrl: './ier-dental-active-table.component.html',
  styleUrls: ['./ier-dental-active-table.component.css']
})
export class IerDentalActiveTableComponent implements OnInit {

  public dataSource: any;
  public myObj: any;
  SearchValue : string = null;
 SearchField : string = null;
 errorMessage:string;
 showErrorMsg: boolean = false;
 showList: boolean = true;

 userID: string;
  isDocNeeded: string;
  agreementStatus: string;
  groupTypeFlag: string;
  productTypeFlag: string;
  parentGroupID :string = null;
  groupID:string = null;
  dentalProductID : string = null;

 displayedColumns: string[] = [ParConstants.parentGroupID, ParConstants.groupID,ParConstants.dentalProductID, ParConstants.effectiveDate, ParConstants.endDate, ParConstants.attachmentName, ParConstants.description];
  
 constructor(
    public router: Router,
    private http: HttpClient,
    private dataStorageService: DataStorageService
  ) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  
  
 

  ngOnInit() {
    
    this.dataStorageService.onGetList(ParConstants.Azure,
      ParConstants.DocNeededN,
      ParConstants.StatusActive,
      ParConstants.IERGroup,
      ParConstants.DProduct).subscribe(responseData =>{
      this.myObj = responseData.successResponse;
    if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
    {
      console.log("in if ");
      this.showList = true;
      this.showErrorMsg = false;
      this.dataSource = new MatTableDataSource(this.myObj);
      this.dataSource.paginator = this.paginator;
    }
    else{
      this.showErrorMsg = true;
              this.showList = false;
                this.errorMessage = responseData.errorDescription;
    } 
      }  
        );
  }

  

  onRowClick(element) {
    console.log(element.parentGroupId + 'clicked..');
    this.router.navigate(['/ierDentalForm']);
  }



  onSearchClick(){
      if(this.SearchField==ParConstants.parentGroupID){
          this.parentGroupID = this.SearchValue;
      }else if(this.SearchField==ParConstants.groupID){
        this.groupID = this.SearchValue;
      }else if(this.SearchField==ParConstants.dentalProductID){
        this.dentalProductID = this.SearchValue;
      }
       
      this.dataStorageService.onSearchIerDental(ParConstants.Azure,
      ParConstants.DocNeededN,
      ParConstants.StatusActive,
      ParConstants.IERGroup,
      ParConstants.DProduct,
      this.parentGroupID,
      this.groupID,
      this.dentalProductID).subscribe(responseData =>{
       
    this.myObj = responseData.successResponse;
    if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
    {
      console.log("in success");
      this.showList = true;
      this.showErrorMsg = false;
      this.dataSource = new MatTableDataSource(this.myObj);
      this.dataSource.paginator = this.paginator;

      console.log("errorDesc "+responseData.errorDescription);
      console.log("responseData success "+responseData.successResponse);
      
    }
    else{
      this.showErrorMsg = true;
              this.showList = false;
                this.errorMessage = responseData.errorDescription;                
                 console.error("errormsg " +this.errorMessage);

    }
    
      }   
        );
  }


}


