import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerDentalActiveTableComponent } from './ier-dental-active-table.component';

describe('IerDentalActiveTableComponent', () => {
  let component: IerDentalActiveTableComponent;
  let fixture: ComponentFixture<IerDentalActiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerDentalActiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerDentalActiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
