import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from "@angular/router";

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})
export class ConfigurationComponent implements AfterViewInit {

  public showConfigTable: boolean = false;
  selectedKeyType;
  data:Array<Object> = [
      {id: 0, name: "productLine"},
      {id: 1, name: "productFamily"},
      {id: 2, name: "version"}
  ];

  selected(){
    // alert(this.selectedKeyType.name);
    // call api to get data on behalf of form values
   // console.log("Inside ........");
    this.showConfigTable = true;
    if (this.showConfigTable) {
      this.showConfigTable = true;
    } else {
      this.showConfigTable = false;
    }
  }

  constructor(
    public router: Router
  ){}

  displayedColumns: string[] = ["slNo", "keyValue", "edit", "delete"];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  configEdit(element){
    // collect row data and send it on edit config screen
    console.log(element.slNo +'clicked..');
    console.log(element.keyValue +'clicked..');
    this.router.navigate(['/admin/configEdit']);
  }

}

export interface PeriodicElement {
  slNo: string;
  keyValue: string;
  edit: string;
  delete: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { slNo: '1', keyValue: "BCD", edit: "EDIT", delete: "DELETE"},
  { slNo: '2', keyValue: "CHiP", edit: "EDIT", delete: "DELETE"},
  { slNo: '3', keyValue: "CLS", edit: "EDIT", delete: "DELETE"},
  { slNo: '4', keyValue: "ESS", edit: "EDIT", delete: "DELETE"},
  { slNo: '5', keyValue: "GP65", edit: "EDIT", delete: "DELETE"},
  { slNo: '6', keyValue: "HM", edit: "EDIT", delete: "DELETE"},
  { slNo: '7', keyValue: "Vision", edit: "EDIT", delete: "DELETE"},
  { slNo: '8', keyValue: "NEHP", edit: "EDIT", delete: "DELETE"},
  { slNo: '9', keyValue: "BDRE", edit: "EDIT", delete: "DELETE"},
  { slNo: '10', keyValue: "RTEW", edit: "EDIT", delete: "DELETE"},
  { slNo: '11', keyValue: "UVHG", edit: "EDIT", delete: "DELETE"},
  { slNo: '12', keyValue: "MILX", edit: "EDIT", delete: "DELETE"}
  ];