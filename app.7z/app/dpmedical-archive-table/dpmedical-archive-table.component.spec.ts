import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DPMedicalArchiveTableComponent } from './dpmedical-archive-table.component';

describe('DPMedicalArchiveTableComponent', () => {
  let component: DPMedicalArchiveTableComponent;
  let fixture: ComponentFixture<DPMedicalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DPMedicalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DPMedicalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
