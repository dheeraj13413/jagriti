export class UserDetails{
    userName: string;
    password: string;
}