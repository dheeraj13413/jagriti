export interface GsaSearchRequestModel
    {
        userID: string,
        isDocNeeded: string,
        agreementStatus: string,
        groupTypeFlag: string,
        productTypeFlag:string,
        parentGroupID ?:string,
        groupID ?:string,
        medicalProductID ?:string,
        visionProductID ?:string,
        pharmacyProductID ?:string
        dentalProductID ?:string,
        pediDentalProductID ?:string,
        pediVisionProductID ?:string
    }


