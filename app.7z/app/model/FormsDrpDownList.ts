export interface FormsDrpDownList
    {
        configurationID: string,
        keyType: string,
        keyValue: string,
        markDelete: string
 
       
    }