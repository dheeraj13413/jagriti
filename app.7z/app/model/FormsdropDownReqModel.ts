export interface FormsdropDownReqModel
    {
        userID:string,
        configurationID:number,
        keyValue:string,
        keyType:string,
        adminFunction:string
 
       
    }