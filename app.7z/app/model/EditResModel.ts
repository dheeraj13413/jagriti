export interface EditResModel
    {
        responseStatus:string,
        responseCode:string,
        responseMessage:string,
        unid:string,
        errorCode: string,
  errorDescription: string
    }