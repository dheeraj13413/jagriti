

import{FormsDrpDownList} from '../model/FormsDrpDownList';

export interface FormsDropDownResModel

    {
  
        data:FormsDrpDownList[];
        // configurationID: string,
        // keyType: string,
        // keyValue: string,
        // markDelete: string
 
       
    }