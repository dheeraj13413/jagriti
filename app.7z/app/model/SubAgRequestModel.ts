export interface SubAgRequestModel
    {
        userID: string,
        isDocNeeded: string,
        agreementStatus: string,
        groupTypeFlag: string,
        productTypeFlag:string,
      
        
       
    }


