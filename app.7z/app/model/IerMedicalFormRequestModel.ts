export interface IerMedicalFormRequestModel
    {
        userID: string,
        isDocNeeded: string,
        agreementStatus: string,
        groupTypeFlag: string,
        productTypeFlag:string,
        unid:string;
      
        
       
    }