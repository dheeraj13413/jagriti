import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from "../service/login-service";

@Component({
  selector: 'app-app-login',
  templateUrl: './app-login.component.html',
  styleUrls: ['./app-login.component.css']
})
export class AppLoginComponent implements OnInit {

  @Input() userDetails = {userName: '', password: ''}

  constructor(
    public loginService: LoginService, 
    public router: Router
  ) { }

  ngOnInit(): void {
  }

  userLogin(){
    this.router.navigate(['/admin'])
  }

  clearForm(){
    this.userDetails.userName = "";
    this.userDetails.password = "";
  }

}
