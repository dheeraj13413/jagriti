import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DataStorageService } from '../service/data-storage.service';
import { ParConstants } from '../globalConstants/par-constants';

@Component({
  selector: 'app-ier-medical-active-table',
  templateUrl: './ier-medical-active-table.component.html',
  styleUrls: ['./ier-medical-active-table.component.css']
})
export class IERMedicalActiveTableComponent implements  OnInit{
 
 public dataSource: MatTableDataSource<any>;
 SearchValue : string = null;
 SearchField : string = null;
  userID: string;
  isDocNeeded: string;
  agreementStatus: string;
  groupTypeFlag: string;
  productTypeFlag: string;
  displayedColumns: string[] = [ParConstants.parentId,ParConstants.groupId,ParConstants.healthProductId,ParConstants.visionId, ParConstants.pharmacyId,ParConstants.startDate, ParConstants.endDate, ParConstants.attachmentName, ParConstants.description];
  errorMessage: string;
  showErrorMsg: boolean = false;
  showList: boolean = true;
  myObj: any = null;
  unid: string;

  parentGroupID :string = null;
  groupID:string = null;
  medicalProductID:string=null;
  visionProductID:string=null;
  pharmacyProductID:string=null;
  status: string;
  
  constructor(
    public router: Router,
    private http : HttpClient,
    private dataStorageService: DataStorageService
  ) { }


  @ViewChild(MatPaginator) paginator: MatPaginator;
 


  ngOnInit() {
    this.dataStorageService.onGetList(ParConstants.Azure,
      ParConstants.DocNeededN,
      ParConstants.StatusActive,
      ParConstants.IERGroup,
      ParConstants.MProduct
      ).subscribe(responseData =>{
       
    this.myObj = responseData.successResponse;
    if(responseData.successResponse!= undefined)
    {
      console.log("in if ");
      this.showList = true;
      this.showErrorMsg = false;
      this.dataSource = new MatTableDataSource(this.myObj);
    this.dataSource.paginator = this.paginator;

       console.log("errorDesc "+responseData.errorDescription);
      console.log("responseData success "+responseData.successResponse);
    }
    else{
      this.showErrorMsg = true;
              this.showList = false;
                this.errorMessage = responseData.errorDescription;
                
                 console.error("errormsg " +this.errorMessage);

    }
    
      }
      
      
        );
   
    }    


  test(element:string,status:string){
this.unid=element;
this.status = status;
    console.log("test");
    console.log("abc "+element);
    console.log("status "+this.status);
  }

  onSearchClick(){
    console.log("SearchValue "+this.SearchValue);
      console.log("SearchField "+this.SearchField); 
      if(this.SearchField==ParConstants.parentGroupID){
          this.parentGroupID = this.SearchValue;
      }else if(this.SearchField==ParConstants.groupID){
        this.groupID = this.SearchValue;
      }else if(this.SearchField==ParConstants.medicalProductID){
        this.medicalProductID = this.SearchValue;
      }else if(this.SearchField==ParConstants.visionProductID){
        this.visionProductID = this.SearchValue;
      }else if(this.SearchField==ParConstants.pharmacyProductID){
        this.pharmacyProductID = this.SearchValue;
      }
       
      this.dataStorageService.onSearchIerMedical(this.userID= 'Azure',
      this.isDocNeeded='N',
      this.agreementStatus='Active',
      this.groupTypeFlag= 'IER',
      this.productTypeFlag='M',
      this.parentGroupID,
      this.groupID,
      this.medicalProductID,
      this.visionProductID,
      this.pharmacyProductID
      ).subscribe(responseData =>{
       
    this.myObj = responseData.successResponse;
    if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
    {
      console.log("in success");
      this.showList = true;
      this.showErrorMsg = false;
      this.dataSource = new MatTableDataSource(this.myObj);
      this.dataSource.paginator = this.paginator;

      console.log("errorDesc "+responseData.errorDescription);
      console.log("responseData success "+responseData.successResponse);
      
    }
    else{
      this.showErrorMsg = true;
              this.showList = false;
                this.errorMessage = responseData.errorDescription;
                
                 console.error("errormsg " +this.errorMessage);

    }
    
      }
      
      
        );
  }



}


