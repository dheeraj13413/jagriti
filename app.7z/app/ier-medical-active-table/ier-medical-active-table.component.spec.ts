import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IERMedicalActiveTableComponent } from './ier-medical-active-table.component';

describe('IERMedicalActiveTableComponent', () => {
  let component: IERMedicalActiveTableComponent;
  let fixture: ComponentFixture<IERMedicalActiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IERMedicalActiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IERMedicalActiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
