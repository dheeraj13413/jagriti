import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DPMedicalInactiveTableComponent } from './dpmedical-inactive-table.component';

describe('DPMedicalInactiveTableComponent', () => {
  let component: DPMedicalInactiveTableComponent;
  let fixture: ComponentFixture<DPMedicalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DPMedicalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DPMedicalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
