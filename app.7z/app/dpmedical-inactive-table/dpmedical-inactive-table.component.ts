import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { SubAgRes } from '../model/SubAgRes';

@Component({
  selector: 'app-dpmedical-inactive-table',
  templateUrl: './dpmedical-inactive-table.component.html',
  styleUrls: ['./dpmedical-inactive-table.component.css']
})
export class DPMedicalInactiveTableComponent implements AfterViewInit, OnInit {

  public dataSource: any;
  public myObj: any;

  constructor(
    public router: Router,
    private http: HttpClient
  ){}

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  apiURL = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/GSA';
  subAgData = { userID: "Azure", isDocNeeded: "N", agreementStatus: "Inactive", groupTypeFlag: "DP", productTypeFlag: "M", parentGroupID: "293" };
  errorMessage;

  ngOnInit() {
    const headers = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' };
    this.http.post<SubAgRes>(this.apiURL, this.subAgData, { headers }).subscribe({
      next: data => {
        console.log("ERR CODE :" + data.errorCode);
        console.log("ERR DESC :" + data.errorDescription);
        //console.log("AgreementName :"+data.successResponse[0].agreementName); 
        this.myObj = data.successResponse;
        this.dataSource = new MatTableDataSource(this.myObj);
      },
      error: error => {
        this.errorMessage = error.message;
        console.error('There was an error!', error);
      }
    })
  }

  displayedColumns: string[] = ["medicalProductId", "visionProductId", "rxProductId", "pediDentalProductId", "pediVisionProductId", 
                                "effectiveDate", "endDate", "attachmentName", "description"];

  public showTable: boolean = false;

  onSearchClick(){
    // call API on behalf of search params
    this.showTable = true;
    if (this.showTable) {
      this.showTable = true;
    } else {
      this.showTable = false;
    }

  }

  onRowClick(element) {
    // call API to collect data of perticular row
    
    this.router.navigate(['/dpMedicalForm'])
  }

}


