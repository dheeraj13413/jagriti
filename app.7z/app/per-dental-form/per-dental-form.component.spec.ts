import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerDentalFormComponent } from './per-dental-form.component';

describe('PerDentalFormComponent', () => {
  let component: PerDentalFormComponent;
  let fixture: ComponentFixture<PerDentalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerDentalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PerDentalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
