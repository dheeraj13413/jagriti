import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppLoginComponent } from "./app-login/app-login.component";
import { AppAdminComponent } from "./app-admin/app-admin.component";
import { AppHeaderComponent } from "./header/header.component";
import { AppFooterComponent } from "./footer/footer.component";
import { AppSideNavComponent } from "./side-nav/side-nav.component";
import { IERMedicalActiveTableComponent } from "./ier-medical-active-table/ier-medical-active-table.component";
import { IerMedicalInactiveTableComponent } from "./ier-medical-inactive-table/ier-medical-inactive-table.component";
import { IerMedicalArchiveTableComponent } from "./ier-medical-archive-table/ier-medical-archive-table.component";
import { IerDentalActiveTableComponent } from "./ier-dental-active-table/ier-dental-active-table.component";
import { IerDentalInactiveTableComponent } from "./ier-dental-inactive-table/ier-dental-inactive-table.component";
import { IerDentalArchiveTableComponent } from "./ier-dental-archive-table/ier-dental-archive-table.component";
import { PERMedicalActiveTableComponent } from "./permedical-active-table/permedical-active-table.component";
import { PERMedicalInactiveTableComponent } from "./permedical-inactive-table/permedical-inactive-table.component";
import { PERMedicalArchiveTableComponent } from "./permedical-archive-table/permedical-archive-table.component";
import { PERDentalActiveTableComponent } from "./perdental-active-table/perdental-active-table.component";
import { PERDentalInactiveTableComponent } from "./perdental-inactive-table/perdental-inactive-table.component";
import { PERDentalArchiveTableComponent } from "./perdental-archive-table/perdental-archive-table.component";
import { DPMedicalActiveTableComponent } from "./dpmedical-active-table/dpmedical-active-table.component";
import { DPMedicalInactiveTableComponent } from "./dpmedical-inactive-table/dpmedical-inactive-table.component";
import { DPMedicalArchiveTableComponent } from "./dpmedical-archive-table/dpmedical-archive-table.component";
import { DPDentalActiveTableComponent } from "./dpdental-active-table/dpdental-active-table.component";
import { DPDentalInactiveTableComponent } from "./dpdental-inactive-table/dpdental-inactive-table.component";
import { DPDentalArchiveTableComponent } from "./dpdental-archive-table/dpdental-archive-table.component";
import { ConfigurationComponent } from "./configuration/configuration.component";
import { ConfigurationEditComponent } from "./configuration-edit/configuration-edit.component";
import { IERMedicalFormComponent } from "./iermedical-form/iermedical-form.component";
import { IerdentalFormComponent } from "./ierdental-form/ierdental-form.component";
import { PerMedicalFormComponent } from "./per-medical-form/per-medical-form.component";
import { PerDentalFormComponent } from "./per-dental-form/per-dental-form.component";
import { DirectPayMedicalFormComponent } from "./direct-pay-medical-form/direct-pay-medical-form.component";
import { DirectPayDentalFormComponent } from "./direct-pay-dental-form/direct-pay-dental-form.component";

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login'},
  { path: 'login', component: AppLoginComponent },
  { path: 'admin', component: AppAdminComponent,
    children:[
      { path: 'ierMedicalActive', component: IERMedicalActiveTableComponent },
      { path: 'ierMedicalInactive', component: IerMedicalInactiveTableComponent },
      { path: 'ierMedicalArchive', component: IerMedicalArchiveTableComponent },
      { path: 'ierDentalActive', component: IerDentalActiveTableComponent },
      { path: 'ierDentalInactive', component: IerDentalInactiveTableComponent },
      { path: 'ierDentalArchive', component: IerDentalArchiveTableComponent },

      { path: 'perMedicalActive', component: PERMedicalActiveTableComponent },
      { path: 'perMedicalInactive', component: PERMedicalInactiveTableComponent },
      { path: 'perMedicalArchive', component: PERMedicalArchiveTableComponent },
      { path: 'perDentalActive', component: PERDentalActiveTableComponent },
      { path: 'perDentalInactive', component: PERDentalInactiveTableComponent },
      { path: 'perDentalArchive', component: PERDentalArchiveTableComponent },

      { path: 'dpMedicalActive', component: DPMedicalActiveTableComponent },
      { path: 'dpMedicalInactive', component: DPMedicalInactiveTableComponent },
      { path: 'dpMedicalArchive', component: DPMedicalArchiveTableComponent },
      { path: 'dpDentalActive', component: DPDentalActiveTableComponent },
      { path: 'dpDentalInactive', component: DPDentalInactiveTableComponent },
      { path: 'dpDentalArchive', component: DPDentalArchiveTableComponent },

      { path: 'configuration', component: ConfigurationComponent },
      { path: 'configEdit', component: ConfigurationEditComponent },
    ]
  },
  { path: 'header', component: AppHeaderComponent },
  { path: 'footer', component: AppFooterComponent },
  { path: 'sideNav', component: AppSideNavComponent },
  { path: 'ierMedicalForm/:unid/:status', component: IERMedicalFormComponent },
  { path: 'ierDentalForm', component: IerdentalFormComponent },
  { path: 'perMedicalForm', component: PerMedicalFormComponent },
  { path: 'perDentalForm', component: PerDentalFormComponent },
  { path: 'dpMedicalForm', component: DirectPayMedicalFormComponent },
  { path: 'dpDentalForm', component: DirectPayDentalFormComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
