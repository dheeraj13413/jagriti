import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DPDentalInactiveTableComponent } from './dpdental-inactive-table.component';

describe('DPDentalInactiveTableComponent', () => {
  let component: DPDentalInactiveTableComponent;
  let fixture: ComponentFixture<DPDentalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DPDentalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DPDentalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
