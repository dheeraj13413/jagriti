import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppSideNavComponent {
  panelOpenState = false;

  public showForClick: boolean = false;
  public currentURL: string = null;

  constructor(
    public router: Router,
  ){}
   

  // IER Medical
  showIERMedicalActiveTable(){
    this.router.navigate(['/admin/ierMedicalActive']);
    
  }
  
  showIERMedicalInactiveTable(){
    this.router.navigate(['/admin/ierMedicalInactive']);
  }

  showIERMedicalArchiveTable(){
    this.router.navigate(['/admin/ierMedicalArchive']);
  }

  showIERDentalActiveTable(){
    this.router.navigateByUrl('/admin/ierDentalActive');
  }

  showIERDentalInactiveTable(){
    this.router.navigate(['/admin/ierDentalInactive']);
  }

  showIERDentalArchiveTable(){
    this.router.navigate(['/admin/ierDentalArchive']);
  }

  // PER Medical/Dental
  showPERMedicalActiveTable(){
    this.router.navigateByUrl('/admin/perMedicalActive');
  }

  showPERMedicalInactiveTable(){
    this.router.navigate(['/admin/perMedicalInactive']);
  }

  showPERMedicalArchiveTable(){
    this.router.navigate(['/admin/perMedicalArchive']);
  }

  showPERDentalActiveTable(){
    this.router.navigateByUrl('/admin/perDentalActive');
  }

  showPERDentalInactiveTable(){
    this.router.navigate(['/admin/perDentalInactive']);
  }

  showPERDentalArchiveTable(){
    this.router.navigate(['/admin/perDentalArchive']);
  }


  // DP Medical/Dental
  showDPMedicalActiveTable(){
    this.router.navigateByUrl('/admin/dpMedicalActive');
  }

  showDPMedicalInactiveTable(){
    this.router.navigate(['/admin/dpMedicalInactive']);
  }

  showDPMedicalArchiveTable(){
    this.router.navigate(['/admin/dpMedicalArchive']);
  }

  showDPDentalActiveTable(){
    this.router.navigateByUrl('/admin/dpDentalActive');
  }

  showDPDentalInactiveTable(){
    this.router.navigate(['/admin/dpDentalInactive']);
  }

  showDPDentalArchiveTable(){
    this.router.navigate(['/admin/dpDentalArchive']);
  }

  // Configuration
  showConfig(){
    this.router.navigate(['/admin/configuration']);
  }
}