import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerMedicalInactiveTableComponent } from './ier-medical-inactive-table.component';

describe('IerMedicalInactiveTableComponent', () => {
  let component: IerMedicalInactiveTableComponent;
  let fixture: ComponentFixture<IerMedicalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerMedicalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerMedicalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
