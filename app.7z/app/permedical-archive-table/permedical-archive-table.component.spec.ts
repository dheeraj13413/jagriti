import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERMedicalArchiveTableComponent } from './permedical-archive-table.component';

describe('PERMedicalArchiveTableComponent', () => {
  let component: PERMedicalArchiveTableComponent;
  let fixture: ComponentFixture<PERMedicalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERMedicalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERMedicalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
