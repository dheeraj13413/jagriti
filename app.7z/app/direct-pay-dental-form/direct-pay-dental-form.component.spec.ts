import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectPayDentalFormComponent } from './direct-pay-dental-form.component';

describe('DirectPayDentalFormComponent', () => {
  let component: DirectPayDentalFormComponent;
  let fixture: ComponentFixture<DirectPayDentalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DirectPayDentalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectPayDentalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
