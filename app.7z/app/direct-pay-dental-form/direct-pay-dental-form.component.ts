import { Component, OnInit } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: 'app-direct-pay-dental-form',
  templateUrl: './direct-pay-dental-form.component.html',
  styleUrls: ['./direct-pay-dental-form.component.css']
})
export class DirectPayDentalFormComponent implements OnInit {

  public disableField: boolean = true;

  constructor(
    public router: Router
  ) { }

  ngOnInit(): void {
  }

  onClose(){
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onEdit(){
    this.disableField = false;
  }

  onDelete(){
    // call delete API of perticular row
    alert("Deleted Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }

  onUpdate(){
    // call update API with perticular row data
    alert("Updated Successfully.....");
    this.router.navigate(['/admin/ierMedicalActive']);
  }


}
