import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERMedicalActiveTableComponent } from './permedical-active-table.component';

describe('PERMedicalActiveTableComponent', () => {
  let component: PERMedicalActiveTableComponent;
  let fixture: ComponentFixture<PERMedicalActiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERMedicalActiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERMedicalActiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
