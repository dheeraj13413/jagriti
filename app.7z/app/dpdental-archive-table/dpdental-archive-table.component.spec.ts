import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DPDentalArchiveTableComponent } from './dpdental-archive-table.component';

describe('DPDentalArchiveTableComponent', () => {
  let component: DPDentalArchiveTableComponent;
  let fixture: ComponentFixture<DPDentalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DPDentalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DPDentalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
