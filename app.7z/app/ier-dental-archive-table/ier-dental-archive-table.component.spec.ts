import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerDentalArchiveTableComponent } from './ier-dental-archive-table.component';

describe('IerDentalArchiveTableComponent', () => {
  let component: IerDentalArchiveTableComponent;
  let fixture: ComponentFixture<IerDentalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerDentalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerDentalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
