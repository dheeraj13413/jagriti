import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ParConstants } from '../globalConstants/par-constants';
import { DataStorageService } from '../service/data-storage.service';

@Component({
  selector: 'app-ier-dental-archive-table',
  templateUrl: './ier-dental-archive-table.component.html',
  styleUrls: ['./ier-dental-archive-table.component.css']
})
export class IerDentalArchiveTableComponent{

  public dataSource: any;
  public myObj: any;
  SearchValue : string = null;
 SearchField : string = null;
 errorMessage:string;
 showErrorMsg: boolean = false;
 showList: boolean = false;

 userID: string;
  isDocNeeded: string;
  agreementStatus: string;
  groupTypeFlag: string;
  productTypeFlag: string;
  parentGroupID :string = null;
  groupID:string = null;
  dentalProductID : string = null;

  constructor(
    public router: Router,
    private http: HttpClient,
    private dataStorageService: DataStorageService
  ) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  displayedColumns: string[] = [ParConstants.parentGroupID, ParConstants.groupID,ParConstants.dentalProductID, ParConstants.effectiveDate, ParConstants.endDate, ParConstants.attachmentName, ParConstants.description, ParConstants.restore];

  
  onSearchClick() {
    this.showList=true;
    // call API on behalf of search params
    if(this.SearchField==ParConstants.parentGroupID){
      this.parentGroupID = this.SearchValue;
  }else if(this.SearchField==ParConstants.groupID){
    this.groupID = this.SearchValue;
  }else if(this.SearchField==ParConstants.dentalProductID){
    this.dentalProductID = this.SearchValue;
  }
   
  this.dataStorageService.onSearchIerDental(ParConstants.Azure,
  ParConstants.DocNeededN,
  ParConstants.StatusArchive,
  ParConstants.IERGroup,
  ParConstants.DProduct,
  this.parentGroupID,
  this.groupID,
  this.dentalProductID).subscribe(responseData =>{
   
this.myObj = responseData.successResponse;
if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
{
  console.log("in success");
  this.showList = true;
  this.showErrorMsg = false;
  this.dataSource = new MatTableDataSource(this.myObj);
  this.dataSource.paginator = this.paginator;

  console.log("errorDesc "+responseData.errorDescription);
  console.log("responseData success "+responseData.successResponse);
  
}
else{
  this.showErrorMsg = true;
          this.showList = false;
            this.errorMessage = responseData.errorDescription;                
             console.error("errormsg " +this.errorMessage);

}

  }   
    );
  }

  onRowClick(element) {
    // call API to collect data of perticular row
    console.log(element.dentalProductId + 'clicked..');
    this.router.navigate(['/ierMedicalForm'])
  }

}


