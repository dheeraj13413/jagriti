import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { ParConstants } from '../globalConstants/par-constants';
import { DataStorageService } from '../service/data-storage.service';

@Component({
  selector: 'app-dpdental-active-table',
  templateUrl: './dpdental-active-table.component.html',
  styleUrls: ['./dpdental-active-table.component.css']
})
export class DPDentalActiveTableComponent implements  OnInit {

  public dataSource: any;
  public myObj: any;
  SearchValue : string = null;
  SearchField : string = null;
  errorMessage:string;
  showErrorMsg: boolean = false;
  showList: boolean = true;
 
  userID: string;
   isDocNeeded: string;
   agreementStatus: string;
   groupTypeFlag: string;
   productTypeFlag: string;
   parentGroupID :string = null;
   groupID:string = null;
   dentalProductID : string = null;

   displayedColumns: string[] = [ParConstants.dentalProductID, ParConstants.effectiveDate, ParConstants.endDate, ParConstants.attachmentName, ParConstants.description];

  constructor(
    public router: Router,
    private http : HttpClient,
    private dataStorageService: DataStorageService
  ){}

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  apiURL = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/GSA';
  subAgData = { userID: "Azure", isDocNeeded: "N", agreementStatus: "Active", groupTypeFlag: "DP", productTypeFlag: "D" };
 

  ngOnInit() {
    this.dataStorageService.onGetList(ParConstants.Azure,
      ParConstants.DocNeededN,
      ParConstants.StatusActive,
      ParConstants.DPGroup,
      ParConstants.DProduct).subscribe(responseData =>{
      this.myObj = responseData.successResponse;
      if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
    {
      console.log("in if ");
      this.showList = true;
      this.showErrorMsg = false;
      this.dataSource = new MatTableDataSource(this.myObj);
      this.dataSource.paginator = this.paginator;
    }
    else{
      this.showErrorMsg = true;
              this.showList = false;
                this.errorMessage = responseData.errorDescription;
    } 
      }  
        );
    }

  

  onRowClick(element) {
    // call API to collect data of perticular row 
    this.router.navigate(['/dpDentalForm']);
  }

  onSearchClick(){
    if(this.SearchField==ParConstants.dentalProductID){
      this.dentalProductID = this.SearchValue;
    }
     
    this.dataStorageService.onSearchDpDental(ParConstants.Azure,
    ParConstants.DocNeededN,
    ParConstants.StatusActive,
    ParConstants.DPGroup,
    ParConstants.DProduct,
    this.dentalProductID).subscribe(responseData =>{
     
  this.myObj = responseData.successResponse;
  if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
  {
    console.log("in success");
    this.showList = true;
    this.showErrorMsg = false;
    this.dataSource = new MatTableDataSource(this.myObj);
    this.dataSource.paginator = this.paginator;
    console.log("errorDesc "+responseData.errorDescription);
    console.log("responseData success "+responseData.successResponse);
    
  }
  else{
    this.showErrorMsg = true;
            this.showList = false;
              this.errorMessage = responseData.errorDescription;                
               console.error("errormsg " +this.errorMessage);

  }
  
    }   
      );
}


}

