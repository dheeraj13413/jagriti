import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerDentalInactiveTableComponent } from './ier-dental-inactive-table.component';

describe('IerDentalInactiveTableComponent', () => {
  let component: IerDentalInactiveTableComponent;
  let fixture: ComponentFixture<IerDentalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerDentalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerDentalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
