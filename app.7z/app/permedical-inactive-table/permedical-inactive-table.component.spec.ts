import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERMedicalInactiveTableComponent } from './permedical-inactive-table.component';

describe('PERMedicalInactiveTableComponent', () => {
  let component: PERMedicalInactiveTableComponent;
  let fixture: ComponentFixture<PERMedicalInactiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERMedicalInactiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERMedicalInactiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
