import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectPayMedicalFormComponent } from './direct-pay-medical-form.component';

describe('DirectPayMedicalFormComponent', () => {
  let component: DirectPayMedicalFormComponent;
  let fixture: ComponentFixture<DirectPayMedicalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DirectPayMedicalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectPayMedicalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
