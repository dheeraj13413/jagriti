import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerdentalFormComponent } from './ierdental-form.component';

describe('IerdentalFormComponent', () => {
  let component: IerdentalFormComponent;
  let fixture: ComponentFixture<IerdentalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerdentalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerdentalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
