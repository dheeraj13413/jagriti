import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';

import { AppSideNavComponent } from './side-nav/side-nav.component';
import { AppHeaderComponent } from './header/header.component';
import { AppFooterComponent } from './footer/footer.component';
import { AppLoginComponent } from './app-login/app-login.component';
import { AppAdminComponent } from './app-admin/app-admin.component';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { SideNavTestComponent } from './side-nav-test/side-nav-test.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatListModule } from "@angular/material/list";

import { IERMedicalActiveTableComponent } from './ier-medical-active-table/ier-medical-active-table.component';
import { IerMedicalInactiveTableComponent } from './ier-medical-inactive-table/ier-medical-inactive-table.component';
import { IerMedicalArchiveTableComponent } from './ier-medical-archive-table/ier-medical-archive-table.component';
import { IerDentalActiveTableComponent } from './ier-dental-active-table/ier-dental-active-table.component';
import { IerDentalInactiveTableComponent } from './ier-dental-inactive-table/ier-dental-inactive-table.component';
import { IerDentalArchiveTableComponent } from './ier-dental-archive-table/ier-dental-archive-table.component';
import { PERMedicalActiveTableComponent } from './permedical-active-table/permedical-active-table.component';
import { PERMedicalInactiveTableComponent } from './permedical-inactive-table/permedical-inactive-table.component';
import { PERMedicalArchiveTableComponent } from './permedical-archive-table/permedical-archive-table.component';
import { PERDentalActiveTableComponent } from './perdental-active-table/perdental-active-table.component';
import { PERDentalInactiveTableComponent } from './perdental-inactive-table/perdental-inactive-table.component';
import { PERDentalArchiveTableComponent } from './perdental-archive-table/perdental-archive-table.component';
import { DPMedicalActiveTableComponent } from './dpmedical-active-table/dpmedical-active-table.component';
import { DPMedicalInactiveTableComponent } from './dpmedical-inactive-table/dpmedical-inactive-table.component';
import { DPDentalArchiveTableComponent } from './dpdental-archive-table/dpdental-archive-table.component';
import { DPMedicalArchiveTableComponent } from './dpmedical-archive-table/dpmedical-archive-table.component';
import { DPDentalInactiveTableComponent } from './dpdental-inactive-table/dpdental-inactive-table.component';
import { DPDentalActiveTableComponent } from './dpdental-active-table/dpdental-active-table.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { ConfigurationEditComponent } from './configuration-edit/configuration-edit.component';
import { IerdentalFormComponent } from './ierdental-form/ierdental-form.component';
import { IERMedicalFormComponent } from './iermedical-form/iermedical-form.component';
import { PerMedicalFormComponent } from './per-medical-form/per-medical-form.component';
import { PerDentalFormComponent } from './per-dental-form/per-dental-form.component';
import { DirectPayMedicalFormComponent } from './direct-pay-medical-form/direct-pay-medical-form.component';
import { DirectPayDentalFormComponent } from './direct-pay-dental-form/direct-pay-dental-form.component';
import { MatSortModule } from '@angular/material/sort';



@NgModule({
  declarations: [
    AppComponent,
    AppSideNavComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppLoginComponent,
    AppAdminComponent,
    SideNavTestComponent,
    IERMedicalActiveTableComponent,
    IerMedicalInactiveTableComponent,
    IerMedicalArchiveTableComponent,
    IerDentalArchiveTableComponent,
    IerDentalInactiveTableComponent,
    IerDentalActiveTableComponent,
    PERMedicalActiveTableComponent,
    PERMedicalInactiveTableComponent,
    PERMedicalArchiveTableComponent,
    PERDentalActiveTableComponent,
    PERDentalInactiveTableComponent,
    PERDentalArchiveTableComponent,
    DPMedicalActiveTableComponent,
    DPMedicalInactiveTableComponent,
    DPMedicalArchiveTableComponent,
    DPDentalActiveTableComponent,
    DPDentalInactiveTableComponent,
    DPDentalArchiveTableComponent,
    ConfigurationComponent,
    ConfigurationEditComponent,
    IERMedicalFormComponent,
    IerdentalFormComponent,
    PerMedicalFormComponent,
    PerDentalFormComponent,
    DirectPayMedicalFormComponent,
    DirectPayDentalFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatSidenavModule,
    HttpClientModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    LayoutModule,
    MatToolbarModule,
    MatListModule,
    MatSortModule
  ],
  exports: [MatSortModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
