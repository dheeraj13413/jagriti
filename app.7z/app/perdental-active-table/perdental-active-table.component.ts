import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { SubAgRes } from '../model/SubAgRes';

@Component({
  selector: 'app-perdental-active-table',
  templateUrl: './perdental-active-table.component.html',
  styleUrls: ['./perdental-active-table.component.css']
})
export class PERDentalActiveTableComponent implements AfterViewInit, OnInit {

  public dataSource: any;
  public myObj: any;

  constructor(
    public router: Router,
    private http : HttpClient
  ){}

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  apiURL = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/GSA';
  subAgData = { userID: "Azure", isDocNeeded: "N", agreementStatus: "Active", groupTypeFlag: "PER", productTypeFlag: "D" };
  errorMessage;

  ngOnInit() {
    //console.log(window.location);
    const headers = { 'Access-Control-Allow-Origin': '*' , 'Content-Type': 'application/json'};
        this.http.post<SubAgRes>(this.apiURL, this.subAgData, { headers }).subscribe({
          next: data => {
            
          console.log("AgreementName :"+data.successResponse[0].agreementName); 
          this.myObj = data.successResponse;
          //this.dataSource = this.myObj;
          //this.myObj = [];
          this.dataSource = new MatTableDataSource(this.myObj);
        },
        error: error => {
            this.errorMessage = error.message;
            console.error('There was an error!', error);
        }
        })
    }

  displayedColumns: string[] = ["dentalProductId", "effectiveDate", "endDate", "attachmentName", "description"];

  onRowClick(element) {
    // call API to collect data of perticular row
    
    this.router.navigate(['/perDentalForm']);
  }

}
