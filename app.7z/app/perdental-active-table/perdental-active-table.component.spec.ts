import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERDentalActiveTableComponent } from './perdental-active-table.component';

describe('PERDentalActiveTableComponent', () => {
  let component: PERDentalActiveTableComponent;
  let fixture: ComponentFixture<PERDentalActiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERDentalActiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERDentalActiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
