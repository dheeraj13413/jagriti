import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DataStorageService } from '../service/data-storage.service';
import { ParConstants } from '../globalConstants/par-constants';

@Component({
  selector: 'app-ier-medical-archive-table',
  templateUrl: './ier-medical-archive-table.component.html',
  styleUrls: ['./ier-medical-archive-table.component.css']
})
export class IerMedicalArchiveTableComponent {

  public dataSource: any;
  public myObj: any;
  SearchValue : string = null;
 SearchField : string = null;
 errorMessage:string;
 showErrorMsg: boolean = false;
 showList: boolean = false;

 userID: string;
  isDocNeeded: string;
  agreementStatus: string;
  groupTypeFlag: string;
  productTypeFlag: string;
  parentGroupID :string = null;
  groupID:string = null;
  medicalProductID : string = null;
  pharmacyProductID:string = null;
  visionProductID:string=null;
  unid: string;


  constructor(
    public router: Router,
    private http: HttpClient,
    private dataStorageService: DataStorageService
  ) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;

    displayedColumns: string[] = ["parentId", "groupId", "healthProductId", "visionId", "pharmacyId",
    "startDate", "endDate", "attachmentName", "description", "restore"];


  public showTable: boolean = false;

   onSearchClick() {
    this.showList=true;
    // call API on behalf of search params
    if(this.SearchField==ParConstants.parentGroupID){
      this.parentGroupID = this.SearchValue;
  }else if(this.SearchField==ParConstants.groupID){
    this.groupID = this.SearchValue;
  }else if(this.SearchField==ParConstants.medicalProductID){
    this.medicalProductID = this.SearchValue;
  }else if(this.SearchField==ParConstants.visionProductID){
    this.visionProductID = this.SearchValue;
  }else if(this.SearchField==ParConstants.pharmacyProductID){
    this.pharmacyProductID = this.SearchValue;
  }
   
  this.dataStorageService.onSearchIerMedical(ParConstants.Azure,
  ParConstants.DocNeededN,
  ParConstants.StatusArchive,
  ParConstants.IERGroup,
  ParConstants.MProduct,
  this.parentGroupID,
  this.groupID,
  this.medicalProductID,
  this.visionProductID,
  this.pharmacyProductID).subscribe(responseData =>{
   
this.myObj = responseData.successResponse;
if(this.myObj!= undefined||this.myObj!=null||this.myObj!='')
{
  console.log("in success");
  this.showList = true;
  this.showErrorMsg = false;
  this.dataSource = new MatTableDataSource(this.myObj);
  this.dataSource.paginator = this.paginator;

  console.log("errorDesc "+responseData.errorDescription);
  console.log("responseData success "+responseData.successResponse);
  
}
else{
  this.showErrorMsg = true;
          this.showList = false;
            this.errorMessage = responseData.errorDescription;                
             console.error("errormsg " +this.errorMessage);

}

  }   
    );
  }


  test(element:string){
    this.unid=element;
        console.log("test");
        console.log("abc "+element);
      }
    

}




