import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IerMedicalArchiveTableComponent } from './ier-medical-archive-table.component';

describe('IerMedicalArchiveTableComponent', () => {
  let component: IerMedicalArchiveTableComponent;
  let fixture: ComponentFixture<IerMedicalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IerMedicalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IerMedicalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
