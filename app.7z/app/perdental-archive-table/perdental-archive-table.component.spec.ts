import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PERDentalArchiveTableComponent } from './perdental-archive-table.component';

describe('PERDentalArchiveTableComponent', () => {
  let component: PERDentalArchiveTableComponent;
  let fixture: ComponentFixture<PERDentalArchiveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PERDentalArchiveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PERDentalArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
