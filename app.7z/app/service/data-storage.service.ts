import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SubAgRequestModel } from '../model/SubAgRequestModel';
import { IerMedicalFormRequestModel } from '../model/IerMedicalFormRequestModel';
import { SubAgRes } from '../model/SubAgRes';
import { FormsDropDownResModel } from '../model/FormsDropDownResModel';
import { FormsdropDownReqModel } from '../model/FormsdropDownReqModel';
import { GsaSearchRequestModel } from '../model/GsaSearchRequestModel';


@Injectable({
  providedIn: 'root'
})
export class DataStorageService {

  apiURL = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/GSA';
  dropDownurl = 'https://azapp-eus2-dev-par-01.azase-eus2-dev-001.appserviceenvironment.net/api/ASA';

  constructor(private http:HttpClient) { }

  onGetList( userID: string,
    isDocNeeded: string,
    agreementStatus: string,
    groupTypeFlag: string,
    productTypeFlag:string ){
            const reqData:SubAgRequestModel = {userID: userID,
              isDocNeeded: isDocNeeded,
              agreementStatus: agreementStatus,
              groupTypeFlag: groupTypeFlag,
              productTypeFlag:productTypeFlag,
              

            };
              
      return  this.http.post<SubAgRes>(
        this.apiURL
            ,reqData
            
            )

          
     
    }

    onGetMedicalFormData( userID: string,
      isDocNeeded: string,
      agreementStatus: string,
      groupTypeFlag: string,
      productTypeFlag:string,
      unid:string ){
              const reqFormData:IerMedicalFormRequestModel = {userID: userID,
                isDocNeeded: isDocNeeded,
                agreementStatus: agreementStatus,
                groupTypeFlag: groupTypeFlag,
                productTypeFlag:productTypeFlag,
                unid:unid
                
  
              };
                
        return  this.http.post<SubAgRes>(
          this.apiURL
              ,reqFormData
              
              )
  
            
       
      }

      onSelectDropDown(userID:string,
      configurationID:number,
      keyValue:string,
      keyType:string,
      adminFunction:string){
        const reqDropDownData:FormsdropDownReqModel = {userID:userID,
          configurationID:configurationID,
          keyValue:keyValue,
          keyType:keyType,
          adminFunction:adminFunction
        
        };
           return this.http.post<FormsDropDownResModel>(this.dropDownurl,reqDropDownData)


      }

//method used for IerMedical
onSearchIerMedical(userID: string,
  isDocNeeded: string,
  agreementStatus: string,
  groupTypeFlag: string,
  productTypeFlag:string,
  parentGroupID:string,
  groupID:string,
  medicalProductID:string,
  visionProductID:string,
  pharmacyProductID:string
  ){
          const reqData:GsaSearchRequestModel = {userID: userID,
            isDocNeeded: isDocNeeded,
            agreementStatus: agreementStatus,
            groupTypeFlag: groupTypeFlag,
            productTypeFlag:productTypeFlag,
            parentGroupID : parentGroupID,
            groupID:groupID,
            medicalProductID:medicalProductID,
            visionProductID:visionProductID,
            pharmacyProductID:pharmacyProductID};
            
    return  this.http.post<SubAgRes>(
      this.apiURL
          ,reqData           
          )
}

//method used for DpDental
onSearchDpDental(userID: string,
isDocNeeded: string,
agreementStatus: string,
groupTypeFlag: string,
productTypeFlag:string,
dentalProductID:string
){
      const reqData:GsaSearchRequestModel = {userID: userID,
        isDocNeeded: isDocNeeded,
        agreementStatus: agreementStatus,
        groupTypeFlag: groupTypeFlag,
        productTypeFlag:productTypeFlag,
        dentalProductID:dentalProductID};
        
return  this.http.post<SubAgRes>(
  this.apiURL
      ,reqData           
      )
}

//method used for IerDental
onSearchIerDental(userID: string,
isDocNeeded: string,
agreementStatus: string,
groupTypeFlag: string,
productTypeFlag:string,
parentGroupID:string,
groupID:string,
dentalProductID:string
){
      const reqData:GsaSearchRequestModel = {userID: userID,
        isDocNeeded: isDocNeeded,
        agreementStatus: agreementStatus,
        groupTypeFlag: groupTypeFlag,
        productTypeFlag:productTypeFlag,
        parentGroupID : parentGroupID,
        groupID:groupID,
        dentalProductID:dentalProductID};
        
return  this.http.post<SubAgRes>(
  this.apiURL
      ,reqData           
      )
}
}
